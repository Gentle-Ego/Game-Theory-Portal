# Game Theory Portal - README

## Panoramica del Progetto

Game Theory Portal è un sito web interattivo dedicato alla teoria dei giochi, che combina contenuti educativi con gameplay pratico. Il portale è stato sviluppato utilizzando esclusivamente tecnologie gratuite e open source, offrendo un'esperienza completa sia per l'apprendimento che per la pratica della teoria dei giochi.

## Caratteristiche Principali

### Contenuti Educativi
- **Timeline Storica**: Evoluzione della teoria dei giochi dalle origini fino all'era contemporanea
- **Concetti Fondamentali**: Spiegazioni dettagliate dei principi chiave della teoria dei giochi
- **Basi Matematiche**: Rappresentazioni formali e dimostrazioni matematiche
- **Casi di Studio**: Applicazioni reali della teoria dei giochi in economia, politica, biologia e tecnologia
- **Tutorial Interattivi**: Guide passo-passo per comprendere i diversi tipi di giochi

### Arena di Gioco
- **Giochi Implementati**:
  - Dilemma del Prigioniero
  - Hawk-Dove Game
  - Stag Hunt
  - Public Goods Game
- **Sistema di Strategie**: Oltre 15 strategie predefinite per i vari giochi
- **Creatore di Strategie**: Interfaccia per creare e testare strategie personalizzate
- **Creatore di Tornei**: Strumento per organizzare competizioni tra diverse strategie

### Funzionalità Sociali
- **Sistema di Autenticazione**: Registrazione e login con email/password, Google o GitHub
- **Profili Utente**: Gestione delle informazioni personali e statistiche di gioco
- **Condivisione di Strategie**: Possibilità di pubblicare e scaricare strategie create dalla community
- **Classifica**: Sistema di ranking basato sulle performance nei tornei

## Stack Tecnologico

### Frontend
- **Framework**: React (Create React App)
- **State Management**: Context API
- **Styling**: Bootstrap e CSS personalizzato
- **Visualizzazione Dati**: Chart.js
- **Routing**: React Router

### Backend
- **Autenticazione**: Firebase Authentication
- **Database**: Firebase Firestore
- **Hosting**: GitHub Pages
- **CI/CD**: GitHub Actions

### Ottimizzazioni
- **Performance**: Code splitting, lazy loading, ottimizzazione delle immagini
- **Sicurezza**: Protezione delle route, sistema di autorizzazione basato su ruoli
- **Accessibilità**: Design responsive per tutti i dispositivi

## Installazione e Configurazione

### Prerequisiti
- Node.js (v14 o superiore)
- npm (v6 o superiore)

### Installazione Locale
1. Clona il repository:
   ```
   git clone https://github.com/yourusername/game-theory-portal.git
   cd game-theory-portal
   ```

2. Installa le dipendenze:
   ```
   cd client
   npm install
   ```

3. Configura Firebase:
   - Crea un progetto su [Firebase Console](https://console.firebase.google.com/)
   - Abilita Authentication e Firestore
   - Copia le credenziali di configurazione
   - Sostituisci i valori in `src/utils/firebase.js` e `src/utils/firestore.js`

4. Avvia l'applicazione in modalità sviluppo:
   ```
   npm start
   ```

### Deployment
Il progetto è configurato per il deployment automatico su GitHub Pages tramite GitHub Actions:

1. Effettua il push del codice sul branch main del tuo repository GitHub
2. L'azione CI/CD configurata in `.github/workflows/deploy.yml` costruirà e pubblicherà automaticamente il sito
3. Il sito sarà accessibile all'URL: `https://yourusername.github.io/game-theory-portal`

## Struttura del Progetto

```
game-theory-portal/
├── client/                  # Frontend React
│   ├── public/              # File statici
│   ├── src/                 # Codice sorgente
│   │   ├── assets/          # Risorse (immagini, contenuti educativi)
│   │   ├── components/      # Componenti React riutilizzabili
│   │   ├── games/           # Implementazione dei giochi
│   │   ├── pages/           # Componenti pagina
│   │   ├── styles/          # File CSS
│   │   ├── tests/           # Test automatizzati
│   │   ├── utils/           # Utilità e configurazioni
│   │   ├── App.js           # Componente principale
│   │   └── index.js         # Punto di ingresso
│   ├── webpack.config.js    # Configurazione di build ottimizzata
│   └── package.json         # Dipendenze e script
├── docs/                    # Documentazione
├── .github/                 # Configurazione GitHub
│   └── workflows/           # Azioni CI/CD
└── README.md                # Questo file
```

## Contribuire al Progetto

Siamo aperti ai contributi! Se desideri migliorare Game Theory Portal:

1. Fai un fork del repository
2. Crea un branch per la tua feature (`git checkout -b feature/amazing-feature`)
3. Committa le tue modifiche (`git commit -m 'Add some amazing feature'`)
4. Pusha il branch (`git push origin feature/amazing-feature`)
5. Apri una Pull Request

## Licenza

Questo progetto è rilasciato sotto licenza MIT - vedi il file LICENSE per i dettagli.

## Contatti

Per domande o suggerimenti, apri un issue sul repository GitHub o contatta il team di sviluppo.

---

Grazie per l'interesse in Game Theory Portal! Speriamo che questo strumento possa essere utile sia per l'apprendimento che per l'esplorazione pratica della teoria dei giochi.
