// Ottimizzazioni delle performance per il Game Theory Portal

// Configurazione per la code splitting e lazy loading
const webpack = require('webpack');
const path = require('path');

module.exports = {
  // Configurazione di base
  entry: './src/index.js',
  output: {
    path: path.resolve(__dirname, 'build'),
    filename: '[name].[contenthash].js',
    chunkFilename: '[name].[contenthash].chunk.js',
    publicPath: '/'
  },
  
  // Ottimizzazione
  optimization: {
    // Suddivide il codice in chunks
    splitChunks: {
      chunks: 'all',
      maxInitialRequests: Infinity,
      minSize: 0,
      cacheGroups: {
        vendor: {
          test: /[\\/]node_modules[\\/]/,
          name(module) {
            // Ottiene il nome del pacchetto npm
            const packageName = module.context.match(/[\\/]node_modules[\\/](.*?)([\\/]|$)/)[1];
            // Crea un nome valido per webpack
            return `npm.${packageName.replace('@', '')}`;
          }
        },
        // Raggruppa i componenti per sezione
        components: {
          test: /[\\/]src[\\/]components[\\/]/,
          name: 'components',
          minChunks: 2
        },
        // Raggruppa le pagine
        pages: {
          test: /[\\/]src[\\/]pages[\\/]/,
          name: 'pages'
        },
        // Raggruppa i giochi
        games: {
          test: /[\\/]src[\\/]games[\\/]/,
          name: 'games'
        },
        // Raggruppa i contenuti educativi
        educational: {
          test: /[\\/]src[\\/]assets[\\/]educational[\\/]/,
          name: 'educational'
        }
      }
    },
    // Estrae il runtime di webpack in un file separato
    runtimeChunk: 'single'
  },
  
  // Plugin per ottimizzare ulteriormente
  plugins: [
    // Definisce le variabili di ambiente
    new webpack.DefinePlugin({
      'process.env.NODE_ENV': JSON.stringify(process.env.NODE_ENV || 'production')
    }),
    // Ottimizza la dimensione dei moduli
    new webpack.optimize.ModuleConcatenationPlugin()
  ],
  
  // Regole per i vari tipi di file
  module: {
    rules: [
      // JavaScript/JSX
      {
        test: /\.(js|jsx)$/,
        exclude: /node_modules/,
        use: {
          loader: 'babel-loader',
          options: {
            presets: ['@babel/preset-env', '@babel/preset-react'],
            plugins: [
              '@babel/plugin-transform-runtime',
              '@babel/plugin-syntax-dynamic-import'
            ]
          }
        }
      },
      // CSS
      {
        test: /\.css$/,
        use: [
          'style-loader',
          'css-loader',
          {
            loader: 'postcss-loader',
            options: {
              postcssOptions: {
                plugins: [
                  'autoprefixer',
                  'cssnano'
                ]
              }
            }
          }
        ]
      },
      // Immagini
      {
        test: /\.(png|svg|jpg|jpeg|gif)$/i,
        type: 'asset',
        parser: {
          dataUrlCondition: {
            maxSize: 8 * 1024 // 8kb
          }
        }
      }
    ]
  },
  
  // Risoluzione dei moduli
  resolve: {
    extensions: ['.js', '.jsx', '.json'],
    alias: {
      '@components': path.resolve(__dirname, 'src/components'),
      '@pages': path.resolve(__dirname, 'src/pages'),
      '@utils': path.resolve(__dirname, 'src/utils'),
      '@games': path.resolve(__dirname, 'src/games'),
      '@assets': path.resolve(__dirname, 'src/assets')
    }
  }
};
