import React, { useState } from 'react';
import { Container, Row, Col, Form, Button, Card, Alert } from 'react-bootstrap';
import { Link, useNavigate } from 'react-router-dom';
import { registerWithEmailAndPassword, loginWithGoogle, loginWithGithub } from '../utils/firebase';
import { useAppContext } from '../utils/AppContext';

const Register = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  
  const { setUser } = useAppContext();
  const navigate = useNavigate();

  const handleRegister = async (e) => {
    e.preventDefault();
    setError('');
    
    // Validazione
    if (password !== confirmPassword) {
      setError('Le password non corrispondono');
      return;
    }
    
    if (password.length < 6) {
      setError('La password deve contenere almeno 6 caratteri');
      return;
    }
    
    setLoading(true);
    
    try {
      const result = await registerWithEmailAndPassword(email, password, displayName);
      
      if (result.success) {
        setUser(result.user);
        navigate('/dashboard');
      } else {
        setError(result.error);
      }
    } catch (err) {
      setError('Si è verificato un errore durante la registrazione. Riprova più tardi.');
      console.error(err);
    }
    
    setLoading(false);
  };

  const handleGoogleRegister = async () => {
    setError('');
    setLoading(true);
    
    try {
      const result = await loginWithGoogle();
      
      if (result.success) {
        setUser(result.user);
        navigate('/dashboard');
      } else {
        setError(result.error);
      }
    } catch (err) {
      setError('Si è verificato un errore durante la registrazione con Google. Riprova più tardi.');
      console.error(err);
    }
    
    setLoading(false);
  };

  const handleGithubRegister = async () => {
    setError('');
    setLoading(true);
    
    try {
      const result = await loginWithGithub();
      
      if (result.success) {
        setUser(result.user);
        navigate('/dashboard');
      } else {
        setError(result.error);
      }
    } catch (err) {
      setError('Si è verificato un errore durante la registrazione con GitHub. Riprova più tardi.');
      console.error(err);
    }
    
    setLoading(false);
  };

  return (
    <Container className="py-5">
      <Row className="justify-content-center">
        <Col md={6}>
          <Card className="shadow">
            <Card.Body className="p-4">
              <h2 className="text-center mb-4">Registrati</h2>
              
              {error && <Alert variant="danger">{error}</Alert>}
              
              <Form onSubmit={handleRegister}>
                <Form.Group className="mb-3" controlId="displayName">
                  <Form.Label>Nome utente</Form.Label>
                  <Form.Control 
                    type="text" 
                    value={displayName}
                    onChange={(e) => setDisplayName(e.target.value)}
                    placeholder="Inserisci il tuo nome utente"
                    required
                  />
                </Form.Group>
                
                <Form.Group className="mb-3" controlId="email">
                  <Form.Label>Email</Form.Label>
                  <Form.Control 
                    type="email" 
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="Inserisci la tua email"
                    required
                  />
                </Form.Group>
                
                <Form.Group className="mb-3" controlId="password">
                  <Form.Label>Password</Form.Label>
                  <Form.Control 
                    type="password" 
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Inserisci una password"
                    required
                  />
                  <Form.Text className="text-muted">
                    La password deve contenere almeno 6 caratteri.
                  </Form.Text>
                </Form.Group>
                
                <Form.Group className="mb-3" controlId="confirmPassword">
                  <Form.Label>Conferma Password</Form.Label>
                  <Form.Control 
                    type="password" 
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="Conferma la tua password"
                    required
                  />
                </Form.Group>
                
                <div className="d-grid mb-3">
                  <Button 
                    variant="primary" 
                    type="submit"
                    disabled={loading}
                  >
                    {loading ? 'Registrazione in corso...' : 'Registrati'}
                  </Button>
                </div>
              </Form>
              
              <hr className="my-4" />
              
              <div className="d-grid gap-2">
                <Button 
                  variant="outline-danger" 
                  onClick={handleGoogleRegister}
                  disabled={loading}
                >
                  <i className="fab fa-google me-2"></i> Registrati con Google
                </Button>
                
                <Button 
                  variant="outline-dark" 
                  onClick={handleGithubRegister}
                  disabled={loading}
                >
                  <i className="fab fa-github me-2"></i> Registrati con GitHub
                </Button>
              </div>
              
              <div className="text-center mt-4">
                Hai già un account? <Link to="/login">Accedi</Link>
              </div>
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </Container>
  );
};

export default Register;
