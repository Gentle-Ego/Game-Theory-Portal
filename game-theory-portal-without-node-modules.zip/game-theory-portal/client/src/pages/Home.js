import React from 'react';
import { Container, Row, Col, Button, Card } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import { useAppContext } from '../utils/AppContext';

const Home = () => {
  const { user } = useAppContext();

  return (
    <div>
      {/* Hero Section */}
      <section className="hero-section">
        <Container>
          <Row className="justify-content-center text-center">
            <Col md={8} className="fade-in">
              <h1 className="display-4 mb-4">Game Theory Portal</h1>
              <p className="lead mb-5">
                Esplora, impara e gioca con i concetti della teoria dei giochi attraverso
                simulazioni interattive e contenuti educativi.
              </p>
              <div>
                <Button as={Link} to="/educational" variant="light" className="me-3 mb-3">
                  Inizia ad Imparare
                </Button>
                <Button as={Link} to="/game-arena" variant="outline-light" className="mb-3">
                  Vai all'Arena di Gioco
                </Button>
              </div>
            </Col>
          </Row>
        </Container>
      </section>

      {/* Value Proposition */}
      <section className="value-proposition">
        <Container>
          <Row className="justify-content-center text-center mb-5">
            <Col md={8}>
              <h2 className="mb-4">Perché Game Theory Portal?</h2>
              <p className="lead">
                Il nostro portale combina l'apprendimento teorico con l'esperienza pratica,
                permettendoti di comprendere la teoria dei giochi attraverso l'interazione diretta.
              </p>
            </Col>
          </Row>
          <Row>
            <Col md={4} className="mb-4">
              <Card className="h-100 slide-in">
                <Card.Body className="text-center">
                  <div className="mb-3">
                    <i className="fas fa-book fa-3x text-primary"></i>
                  </div>
                  <Card.Title>Impara</Card.Title>
                  <Card.Text>
                    Esplora i concetti fondamentali della teoria dei giochi attraverso
                    contenuti educativi interattivi e facili da comprendere.
                  </Card.Text>
                </Card.Body>
              </Card>
            </Col>
            <Col md={4} className="mb-4">
              <Card className="h-100 slide-in">
                <Card.Body className="text-center">
                  <div className="mb-3">
                    <i className="fas fa-gamepad fa-3x text-secondary"></i>
                  </div>
                  <Card.Title>Gioca</Card.Title>
                  <Card.Text>
                    Metti alla prova le tue conoscenze in scenari di gioco reali e
                    sperimenta diverse strategie in prima persona.
                  </Card.Text>
                </Card.Body>
              </Card>
            </Col>
            <Col md={4} className="mb-4">
              <Card className="h-100 slide-in">
                <Card.Body className="text-center">
                  <div className="mb-3">
                    <i className="fas fa-users fa-3x text-accent"></i>
                  </div>
                  <Card.Title>Condividi</Card.Title>
                  <Card.Text>
                    Unisciti alla community, condividi le tue strategie e partecipa a
                    tornei con altri appassionati di teoria dei giochi.
                  </Card.Text>
                </Card.Body>
              </Card>
            </Col>
          </Row>
        </Container>
      </section>

      {/* Featured Content */}
      <section className="featured-content">
        <Container>
          <h2 className="text-center mb-5">Concetti Chiave della Teoria dei Giochi</h2>
          <Row>
            <Col md={6} lg={3} className="mb-4">
              <Card className="h-100">
                <Card.Body>
                  <Card.Title>Dilemma del Prigioniero</Card.Title>
                  <Card.Text>
                    Un classico problema che dimostra perché due individui potrebbero non cooperare
                    anche quando sarebbe nel loro interesse farlo.
                  </Card.Text>
                  <Button as={Link} to="/educational/concepts" variant="primary" size="sm">
                    Scopri di più
                  </Button>
                </Card.Body>
              </Card>
            </Col>
            <Col md={6} lg={3} className="mb-4">
              <Card className="h-100">
                <Card.Body>
                  <Card.Title>Equilibrio di Nash</Card.Title>
                  <Card.Text>
                    Una situazione in cui nessun giocatore può migliorare il proprio risultato
                    cambiando solo la propria strategia.
                  </Card.Text>
                  <Button as={Link} to="/educational/concepts" variant="primary" size="sm">
                    Scopri di più
                  </Button>
                </Card.Body>
              </Card>
            </Col>
            <Col md={6} lg={3} className="mb-4">
              <Card className="h-100">
                <Card.Body>
                  <Card.Title>Strategie Dominanti</Card.Title>
                  <Card.Text>
                    Strategie che offrono risultati migliori indipendentemente dalle scelte
                    degli altri giocatori.
                  </Card.Text>
                  <Button as={Link} to="/educational/concepts" variant="primary" size="sm">
                    Scopri di più
                  </Button>
                </Card.Body>
              </Card>
            </Col>
            <Col md={6} lg={3} className="mb-4">
              <Card className="h-100">
                <Card.Body>
                  <Card.Title>Giochi a Somma Zero</Card.Title>
                  <Card.Text>
                    Situazioni in cui il guadagno di un giocatore corrisponde esattamente
                    alla perdita dell'altro.
                  </Card.Text>
                  <Button as={Link} to="/educational/concepts" variant="primary" size="sm">
                    Scopri di più
                  </Button>
                </Card.Body>
              </Card>
            </Col>
          </Row>
        </Container>
      </section>

      {/* Quick Start */}
      <section className="quick-start">
        <Container>
          <Row className="align-items-center">
            <Col md={6} className="mb-4 mb-md-0">
              <h2>Prova Subito il Dilemma del Prigioniero</h2>
              <p className="lead">
                Sperimenta uno dei più famosi scenari della teoria dei giochi direttamente
                dal tuo browser, senza bisogno di registrazione.
              </p>
              <Button as={Link} to="/game-arena/prisoners-dilemma" variant="light" size="lg">
                Gioca Ora
              </Button>
            </Col>
            <Col md={6}>
              <Card className="game-preview">
                <Card.Body className="text-center p-5">
                  <h3>Dilemma del Prigioniero</h3>
                  <div className="d-flex justify-content-around my-4">
                    <div className="text-center">
                      <div className="choice-box cooperate">Coopera</div>
                      <p className="mt-2">+3 punti se entrambi cooperano</p>
                    </div>
                    <div className="text-center">
                      <div className="choice-box defect">Tradisci</div>
                      <p className="mt-2">+5 punti se tradisci e l'altro coopera</p>
                    </div>
                  </div>
                </Card.Body>
              </Card>
            </Col>
          </Row>
        </Container>
      </section>

      {/* User Dashboard (only for logged in users) */}
      {user && (
        <section className="py-5">
          <Container>
            <div className="user-dashboard">
              <h2 className="mb-4">Il Tuo Dashboard</h2>
              <Row>
                <Col md={4} className="mb-4">
                  <Card>
                    <Card.Body>
                      <Card.Title>Le Tue Statistiche</Card.Title>
                      <div className="d-flex justify-content-between my-3">
                        <div>Partite Giocate:</div>
                        <div>{user.stats?.gamesPlayed || 0}</div>
                      </div>
                      <div className="d-flex justify-content-between my-3">
                        <div>Vittorie:</div>
                        <div>{user.stats?.wins || 0}</div>
                      </div>
                      <div className="d-flex justify-content-between my-3">
                        <div>Sconfitte:</div>
                        <div>{user.stats?.losses || 0}</div>
                      </div>
                      <Button as={Link} to="/profile" variant="outline-primary" size="sm" className="mt-3">
                        Vedi Profilo Completo
                      </Button>
                    </Card.Body>
                  </Card>
                </Col>
                <Col md={8} className="mb-4">
                  <Card>
                    <Card.Body>
                      <Card.Title>Giochi in Corso</Card.Title>
                      {user.activeGames?.length > 0 ? (
                        <div className="list-group">
                          {user.activeGames.map(game => (
                            <Link
                              key={game.id}
                              to={`/game-arena/${game.type}/${game.id}`}
                              className="list-group-item list-group-item-action d-flex justify-content-between align-items-center"
                            >
                              <div>
                                <h6 className="mb-1">{game.name}</h6>
                                <small>vs {game.opponent}</small>
                              </div>
                              <span className="badge bg-primary rounded-pill">Continua</span>
                            </Link>
                          ))}
                        </div>
                      ) : (
                        <p className="text-center my-4">
                          Non hai giochi in corso.{' '}
                          <Link to="/game-arena">Inizia una nuova partita</Link>
                        </p>
                      )}
                    </Card.Body>
                  </Card>
                </Col>
              </Row>
            </div>
          </Container>
        </section>
      )}
    </div>
  );
};

export default Home;
