import React from 'react';
import { Container, Row, Col, Card, Button } from 'react-bootstrap';
import { Link } from 'react-router-dom';

const NotFound = () => {
  return (
    <Container className="py-5">
      <Row className="justify-content-center">
        <Col md={8} className="text-center">
          <Card className="shadow-sm">
            <Card.Body className="p-5">
              <h1 className="display-4 mb-4">404</h1>
              <h2 className="mb-4">Pagina Non Trovata</h2>
              <p className="lead mb-4">
                La pagina che stai cercando non esiste o è stata spostata.
              </p>
              <Button as={Link} to="/" variant="primary" size="lg">
                Torna alla Home
              </Button>
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </Container>
  );
};

export default NotFound;
