import React, { useState, useEffect } from 'react';
import { Container, Row, Col, Card, Button, Tabs, Tab, Form } from 'react-bootstrap';
import { Link, Routes, Route, useNavigate, useLocation } from 'react-router-dom';
import { fetchGames, fetchStrategies } from '../utils/api';
import { useAppContext } from '../utils/AppContext';

// Componenti per i singoli giochi
const PrisonersDilemma = () => {
  const [playerChoice, setPlayerChoice] = useState(null);
  const [opponentChoice, setOpponentChoice] = useState(null);
  const [result, setResult] = useState(null);
  const [score, setScore] = useState({ player: 0, opponent: 0 });
  const [round, setRound] = useState(1);
  const [gameHistory, setGameHistory] = useState([]);
  const [selectedStrategy, setSelectedStrategy] = useState('random');
  const [strategies, setStrategies] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadStrategies = async () => {
      try {
        const data = await fetchStrategies();
        setStrategies(data);
      } catch (error) {
        console.error('Errore nel caricamento delle strategie:', error);
      } finally {
        setLoading(false);
      }
    };

    loadStrategies();
  }, []);

  const getOpponentChoice = () => {
    // Implementazione semplificata della strategia dell'avversario
    if (selectedStrategy === 'random') {
      return Math.random() > 0.5 ? 'cooperate' : 'defect';
    } else if (selectedStrategy === 'alwaysDefect') {
      return 'defect';
    } else if (selectedStrategy === 'alwaysCooperate') {
      return 'cooperate';
    } else if (selectedStrategy === 'titForTat') {
      if (gameHistory.length === 0) {
        return 'cooperate';
      }
      return gameHistory[gameHistory.length - 1].playerChoice;
    }
    return 'cooperate'; // Default
  };

  const calculateResult = (player, opponent) => {
    if (player === 'cooperate' && opponent === 'cooperate') {
      return { player: 3, opponent: 3, message: 'Entrambi avete cooperato! +3 punti ciascuno.' };
    } else if (player === 'cooperate' && opponent === 'defect') {
      return { player: 0, opponent: 5, message: 'Hai cooperato ma l\'avversario ha tradito! +0 punti per te, +5 per l\'avversario.' };
    } else if (player === 'defect' && opponent === 'cooperate') {
      return { player: 5, opponent: 0, message: 'Hai tradito mentre l\'avversario ha cooperato! +5 punti per te, +0 per l\'avversario.' };
    } else {
      return { player: 1, opponent: 1, message: 'Entrambi avete tradito! +1 punto ciascuno.' };
    }
  };

  const makeChoice = (choice) => {
    if (playerChoice) return; // Impedisce scelte multiple nello stesso round

    setPlayerChoice(choice);
    const opponent = getOpponentChoice();
    setOpponentChoice(opponent);

    const roundResult = calculateResult(choice, opponent);
    setResult(roundResult);

    setScore({
      player: score.player + roundResult.player,
      opponent: score.opponent + roundResult.opponent
    });

    setGameHistory([
      ...gameHistory,
      {
        round,
        playerChoice: choice,
        opponentChoice: opponent,
        playerScore: roundResult.player,
        opponentScore: roundResult.opponent
      }
    ]);
  };

  const nextRound = () => {
    setPlayerChoice(null);
    setOpponentChoice(null);
    setResult(null);
    setRound(round + 1);
  };

  const resetGame = () => {
    setPlayerChoice(null);
    setOpponentChoice(null);
    setResult(null);
    setScore({ player: 0, opponent: 0 });
    setRound(1);
    setGameHistory([]);
  };

  if (loading) {
    return <div className="text-center py-5">Caricamento gioco...</div>;
  }

  return (
    <div>
      <h2 className="mb-4">Dilemma del Prigioniero</h2>
      <p className="lead">
        Nel Dilemma del Prigioniero, due giocatori devono decidere se cooperare o tradire.
        La cooperazione reciproca porta a risultati moderatamente buoni per entrambi,
        mentre la defezione unilaterale offre un vantaggio a chi tradisce a spese di chi coopera.
        Se entrambi tradiscono, entrambi ottengono risultati peggiori rispetto alla cooperazione reciproca.
      </p>

      <Card className="mb-4">
        <Card.Body>
          <Row>
            <Col md={4}>
              <h4>Punteggio</h4>
              <div className="d-flex justify-content-between my-3">
                <div>Tu:</div>
                <div>{score.player}</div>
              </div>
              <div className="d-flex justify-content-between my-3">
                <div>Avversario:</div>
                <div>{score.opponent}</div>
              </div>
              <div className="d-flex justify-content-between my-3">
                <div>Round:</div>
                <div>{round}</div>
              </div>
            </Col>
            <Col md={8}>
              <h4>Strategia Avversario</h4>
              <Form.Select 
                className="mb-3"
                value={selectedStrategy}
                onChange={(e) => setSelectedStrategy(e.target.value)}
                disabled={gameHistory.length > 0}
              >
                <option value="random">Casuale</option>
                <option value="alwaysDefect">Sempre Tradisci</option>
                <option value="alwaysCooperate">Sempre Coopera</option>
                <option value="titForTat">Tit for Tat</option>
              </Form.Select>
              
              {!playerChoice ? (
                <div>
                  <h4>Fai la tua scelta:</h4>
                  <div className="d-flex justify-content-around my-4">
                    <Button 
                      variant="success" 
                      size="lg" 
                      onClick={() => makeChoice('cooperate')}
                      className="px-4 py-3"
                    >
                      Coopera
                    </Button>
                    <Button 
                      variant="danger" 
                      size="lg" 
                      onClick={() => makeChoice('defect')}
                      className="px-4 py-3"
                    >
                      Tradisci
                    </Button>
                  </div>
                </div>
              ) : (
                <div className="text-center">
                  <h4>Risultato del Round {round}:</h4>
                  <p className="lead">{result.message}</p>
                  <div className="d-flex justify-content-around my-4">
                    <div className="text-center">
                      <h5>La tua scelta:</h5>
                      <div className={`choice-box ${playerChoice === 'cooperate' ? 'bg-success' : 'bg-danger'} text-white p-3 rounded`}>
                        {playerChoice === 'cooperate' ? 'Coopera' : 'Tradisci'}
                      </div>
                    </div>
                    <div className="text-center">
                      <h5>Scelta avversario:</h5>
                      <div className={`choice-box ${opponentChoice === 'cooperate' ? 'bg-success' : 'bg-danger'} text-white p-3 rounded`}>
                        {opponentChoice === 'cooperate' ? 'Coopera' : 'Tradisci'}
                      </div>
                    </div>
                  </div>
                  <Button 
                    variant="primary" 
                    size="lg" 
                    onClick={nextRound}
                    className="mt-3 me-2"
                  >
                    Prossimo Round
                  </Button>
                  <Button 
                    variant="outline-secondary" 
                    size="lg" 
                    onClick={resetGame}
                    className="mt-3"
                  >
                    Ricomincia
                  </Button>
                </div>
              )}
            </Col>
          </Row>
        </Card.Body>
      </Card>

      {gameHistory.length > 0 && (
        <Card>
          <Card.Body>
            <h4>Cronologia Partita</h4>
            <div className="table-responsive">
              <table className="table table-striped">
                <thead>
                  <tr>
                    <th>Round</th>
                    <th>Tua Scelta</th>
                    <th>Scelta Avversario</th>
                    <th>Tuoi Punti</th>
                    <th>Punti Avversario</th>
                  </tr>
                </thead>
                <tbody>
                  {gameHistory.map((history, index) => (
                    <tr key={index}>
                      <td>{history.round}</td>
                      <td>{history.playerChoice === 'cooperate' ? 'Coopera' : 'Tradisci'}</td>
                      <td>{history.opponentChoice === 'cooperate' ? 'Coopera' : 'Tradisci'}</td>
                      <td>{history.playerScore}</td>
                      <td>{history.opponentScore}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card.Body>
        </Card>
      )}
    </div>
  );
};

const HawkDove = () => {
  return (
    <div>
      <h2 className="mb-4">Hawk-Dove Game</h2>
      <p className="lead">
        Il gioco Hawk-Dove (Falco-Colomba) modella il conflitto tra comportamenti aggressivi e pacifici.
        Questo gioco sarà disponibile nella prossima versione.
      </p>
      <Card className="text-center p-5">
        <Card.Body>
          <h3>Coming Soon</h3>
          <p>Stiamo lavorando all'implementazione di questo gioco. Torna presto!</p>
        </Card.Body>
      </Card>
    </div>
  );
};

const StagHunt = () => {
  return (
    <div>
      <h2 className="mb-4">Stag Hunt</h2>
      <p className="lead">
        Stag Hunt è un gioco che modella il conflitto tra sicurezza e cooperazione sociale.
        Questo gioco sarà disponibile nella prossima versione.
      </p>
      <Card className="text-center p-5">
        <Card.Body>
          <h3>Coming Soon</h3>
          <p>Stiamo lavorando all'implementazione di questo gioco. Torna presto!</p>
        </Card.Body>
      </Card>
    </div>
  );
};

const PublicGoods = () => {
  return (
    <div>
      <h2 className="mb-4">Public Goods Game</h2>
      <p className="lead">
        Il Public Goods Game esplora come gli individui contribuiscono a un bene comune.
        Questo gioco sarà disponibile nella prossima versione.
      </p>
      <Card className="text-center p-5">
        <Card.Body>
          <h3>Coming Soon</h3>
          <p>Stiamo lavorando all'implementazione di questo gioco. Torna presto!</p>
        </Card.Body>
      </Card>
    </div>
  );
};

const StrategyBuilder = () => {
  const [code, setCode] = useState('function myStrategy(history) {\n  // history è un array di oggetti {player: "cooperate"/"defect", opponent: "cooperate"/"defect"}\n  // Restituisci "cooperate" o "defect"\n  \n  // Esempio: Tit for Tat\n  if (history.length === 0) return "cooperate";\n  return history[history.length - 1].opponent;\n}');
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [saveStatus, setSaveStatus] = useState('');

  const handleSave = () => {
    // Qui andrebbe implementata la logica per salvare la strategia
    setSaveStatus('Strategia salvata con successo!');
    setTimeout(() => setSaveStatus(''), 3000);
  };

  return (
    <div>
      <h2 className="mb-4">Strategy Builder</h2>
      <p className="lead">
        Crea la tua strategia personalizzata per il Dilemma del Prigioniero.
        Scrivi una funzione JavaScript che prende la cronologia delle mosse e restituisce "cooperate" o "defect".
      </p>
      
      <Card className="mb-4">
        <Card.Body>
          <Form>
            <Form.Group className="mb-3">
              <Form.Label>Nome Strategia</Form.Label>
              <Form.Control 
                type="text" 
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Es. La mia Tit for Tat migliorata"
              />
            </Form.Group>
            
            <Form.Group className="mb-3">
              <Form.Label>Descrizione</Form.Label>
              <Form.Control 
                as="textarea" 
                rows={2}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Descrivi brevemente come funziona la tua strategia"
              />
            </Form.Group>
            
            <Form.Group className="mb-3">
              <Form.Label>Codice</Form.Label>
              <Form.Control 
                as="textarea" 
                rows={10}
                value={code}
                onChange={(e) => setCode(e.target.value)}
                className="font-monospace"
              />
            </Form.Group>
            
            <Button variant="primary" onClick={handleSave}>
              Salva Strategia
            </Button>
            
            {saveStatus && (
              <div className="alert alert-success mt-3">
                {saveStatus}
              </div>
            )}
          </Form>
        </Card.Body>
      </Card>
      
      <Card>
        <Card.Body>
          <h4>Guida alla Creazione di Strategie</h4>
          <p>
            La tua funzione riceverà un parametro <code>history</code>, che è un array di oggetti
            rappresentanti la cronologia delle mosse. Ogni oggetto ha due proprietà:
          </p>
          <ul>
            <li><code>player</code>: la tua mossa precedente ("cooperate" o "defect")</li>
            <li><code>opponent</code>: la mossa dell'avversario ("cooperate" o "defect")</li>
          </ul>
          <p>
            La funzione deve restituire "cooperate" o "defect" come stringa.
            Se <code>history.length === 0</code>, significa che è il primo turno.
          </p>
          <h5>Esempi di Strategie:</h5>
          <pre className="bg-light p-3 rounded">
{`// Tit for Tat
function titForTat(history) {
  if (history.length === 0) return "cooperate";
  return history[history.length - 1].opponent;
}

// Always Defect
function alwaysDefect(history) {
  return "defect";
}

// Pavlov (Win-Stay, Lose-Shift)
function pavlov(history) {
  if (history.length === 0) return "cooperate";
  const lastRound = history[history.length - 1];
  if (lastRound.player === lastRound.opponent) {
    return lastRound.player; // Mantieni la stessa mossa se hai vinto
  } else {
    return lastRound.player === "cooperate" ? "defect" : "cooperate"; // Cambia se hai perso
  }
}`}
          </pre>
        </Card.Body>
      </Card>
    </div>
  );
};

// Componente principale GameArena
const GameArena = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [games, setGames] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeKey, setActiveKey] = useState('games');

  useEffect(() => {
    const loadGames = async () => {
      try {
        const data = await fetchGames();
        setGames(data);
      } catch (error) {
        console.error('Errore nel caricamento dei giochi:', error);
      } finally {
        setLoading(false);
      }
    };

    loadGames();

    // Imposta la tab attiva in base al percorso
    const path = location.pathname.split('/').pop();
    if (path && path !== 'game-arena') {
      if (path === 'strategy-builder') {
        setActiveKey('strategy-builder');
      } else {
        setActiveKey('games');
      }
    }
  }, [location]);

  const handleSelect = (key) => {
    setActiveKey(key);
    if (key === 'strategy-builder') {
      navigate('/game-arena/strategy-builder');
    } else {
      navigate('/game-arena');
    }
  };

  if (loading) {
    return <div className="text-center py-5">Caricamento giochi...</div>;
  }

  return (
    <Container className="py-4">
      <h1 className="text-center mb-5">Arena di Gioco</h1>
      
      <Tabs
        activeKey={activeKey}
        onSelect={handleSelect}
        className="mb-4"
      >
        <Tab eventKey="games" title="Giochi">
          <Row>
            <Col md={6} lg={3} className="mb-4">
              <Card className="h-100">
                <Card.Body className="d-flex flex-column">
                  <Card.Title>Dilemma del Prigioniero</Card.Title>
                  <Card.Text>
                    Un classico problema che dimostra perché due individui potrebbero non cooperare
                    anche quando sarebbe nel loro interesse farlo.
                  </Card.Text>
                  <Button 
                    as={Link} 
                    to="/game-arena/prisoners-dilemma" 
                    variant="primary"
                    className="mt-auto"
                  >
                    Gioca
                  </Button>
                </Card.Body>
              </Card>
            </Col>
            <Col md={6} lg={3} className="mb-4">
              <Card className="h-100">
                <Card.Body className="d-flex flex-column">
                  <Card.Title>Hawk-Dove Game</Card.Title>
                  <Card.Text>
                    Un gioco che modella il conflitto tra comportamenti aggressivi e pacifici.
                  </Card.Text>
                  <Button 
                    as={Link} 
                    to="/game-arena/hawk-dove" 
                    variant="primary"
                    className="mt-auto"
                    disabled
                  >
                    Coming Soon
                  </Button>
                </Card.Body>
              </Card>
            </Col>
            <Col md={6} lg={3} className="mb-4">
              <Card className="h-100">
                <Card.Body className="d-flex flex-column">
                  <Card.Title>Stag Hunt</Card.Title>
                  <Card.Text>
                    Un gioco che modella il conflitto tra sicurezza e cooperazione sociale.
                  </Card.Text>
                  <Button 
                    as={Link} 
                    to="/game-arena/stag-hunt" 
                    variant="primary"
                    className="mt-auto"
                    disabled
                  >
                    Coming Soon
                  </Button>
                </Card.Body>
              </Card>
            </Col>
            <Col md={6} lg={3} className="mb-4">
              <Card className="h-100">
                <Card.Body className="d-flex flex-column">
                  <Card.Title>Public Goods Game</Card.Title>
                  <Card.Text>
                    Un gioco che esplora come gli individui contribuiscono a un bene comune.
                  </Card.Text>
                  <Button 
                    as={Link} 
                    to="/game-arena/public-goods" 
                    variant="primary"
                    className="mt-auto"
                    disabled
                  >
                    Coming Soon
                  </Button>
                </Card.Body>
              </Card>
            </Col>
          </Row>
        </Tab>
        <Tab eventKey="strategy-builder" title="Strategy Builder">
          <StrategyBuilder />
        </Tab>
      </Tabs>
      
      <Routes>
        <Route path="/" element={null} />
        <Route path="/prisoners-dilemma" element={<PrisonersDilemma />} />
        <Route path="/hawk-dove" element={<HawkDove />} />
        <Route path="/stag-hunt" element={<StagHunt />} />
        <Route path="/public-goods" element={<PublicGoods />} />
        <Route path="/strategy-builder" element={<StrategyBuilder />} />
      </Routes>
    </Container>
  );
};

export default GameArena;
