import React, { useState, useEffect } from 'react';
import { Container, Row, Col, Card, Button, Form, ListGroup, Badge } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import { useAppContext } from '../utils/AppContext';

const Multiplayer = () => {
  const { user } = useAppContext();
  const [activeGames, setActiveGames] = useState([]);
  const [availableChallenges, setAvailableChallenges] = useState([]);
  const [loading, setLoading] = useState(true);
  const [newChallenge, setNewChallenge] = useState({
    title: '',
    gameType: 'prisoners-dilemma',
    rounds: 10,
    description: ''
  });
  const [challengeLink, setChallengeLink] = useState('');

  useEffect(() => {
    // Simulazione del caricamento dei dati
    setTimeout(() => {
      setActiveGames([
        {
          id: 1,
          title: 'Dilemma del Prigioniero - Torneo Settimanale',
          opponent: 'user456',
          gameType: 'prisoners-dilemma',
          status: 'in_progress',
          yourTurn: true,
          rounds: 10,
          currentRound: 3,
          score: { player: 9, opponent: 7 }
        },
        {
          id: 2,
          title: 'Sfida Amichevole',
          opponent: 'user789',
          gameType: 'prisoners-dilemma',
          status: 'in_progress',
          yourTurn: false,
          rounds: 5,
          currentRound: 5,
          score: { player: 12, opponent: 15 }
        }
      ]);
      
      setAvailableChallenges([
        {
          id: 101,
          title: 'Sfida Aperta - Dilemma del Prigioniero',
          creator: 'user555',
          gameType: 'prisoners-dilemma',
          rounds: 10,
          createdAt: '2025-03-20T14:30:00Z',
          description: 'Sfida aperta a chiunque voglia partecipare. Strategia personalizzata.'
        },
        {
          id: 102,
          title: 'Torneo Principianti',
          creator: 'user777',
          gameType: 'prisoners-dilemma',
          rounds: 5,
          createdAt: '2025-03-22T09:15:00Z',
          description: 'Torneo per principianti. Massimo 10 partecipanti.'
        }
      ]);
      
      setLoading(false);
    }, 1000);
  }, []);

  const handleCreateChallenge = (e) => {
    e.preventDefault();
    
    // Simulazione della creazione di una sfida
    const challengeId = Math.floor(Math.random() * 1000) + 200;
    const shareableLink = `https://game-theory-portal.example.com/challenge/${challengeId}`;
    
    setChallengeLink(shareableLink);
    
    // Reset del form
    setNewChallenge({
      title: '',
      gameType: 'prisoners-dilemma',
      rounds: 10,
      description: ''
    });
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewChallenge({
      ...newChallenge,
      [name]: value
    });
  };

  if (loading) {
    return <div className="text-center py-5">Caricamento partite multiplayer...</div>;
  }

  return (
    <Container className="py-4">
      <h1 className="text-center mb-5">Multiplayer</h1>
      
      {!user ? (
        <Card className="text-center mb-5">
          <Card.Body>
            <Card.Title>Accedi per Giocare in Multiplayer</Card.Title>
            <Card.Text>
              Per partecipare a partite multiplayer, creare sfide o unirti a tornei,
              è necessario effettuare l'accesso o registrarsi.
            </Card.Text>
            <Button as={Link} to="/login" variant="primary" className="me-2">Accedi</Button>
            <Button as={Link} to="/register" variant="outline-primary">Registrati</Button>
          </Card.Body>
        </Card>
      ) : (
        <>
          {/* Partite Attive */}
          <h2 className="mb-4">Le Tue Partite</h2>
          {activeGames.length > 0 ? (
            <Row>
              {activeGames.map(game => (
                <Col md={6} key={game.id} className="mb-4">
                  <Card>
                    <Card.Body>
                      <Card.Title>{game.title}</Card.Title>
                      <Card.Subtitle className="mb-2 text-muted">
                        Contro: {game.opponent}
                      </Card.Subtitle>
                      <div className="d-flex justify-content-between my-3">
                        <div>Tipo di Gioco:</div>
                        <div>
                          {game.gameType === 'prisoners-dilemma' ? 'Dilemma del Prigioniero' : game.gameType}
                        </div>
                      </div>
                      <div className="d-flex justify-content-between my-3">
                        <div>Round:</div>
                        <div>{game.currentRound} / {game.rounds}</div>
                      </div>
                      <div className="d-flex justify-content-between my-3">
                        <div>Punteggio:</div>
                        <div>Tu: {game.score.player} - Avversario: {game.score.opponent}</div>
                      </div>
                      <div className="d-flex justify-content-between my-3">
                        <div>Stato:</div>
                        <div>
                          {game.yourTurn ? (
                            <Badge bg="success">È il tuo turno</Badge>
                          ) : (
                            <Badge bg="warning">In attesa dell'avversario</Badge>
                          )}
                        </div>
                      </div>
                      <div className="text-center mt-4">
                        <Button 
                          as={Link} 
                          to={`/multiplayer/game/${game.id}`}
                          variant={game.yourTurn ? "primary" : "outline-primary"}
                          disabled={!game.yourTurn}
                        >
                          {game.yourTurn ? "Gioca il tuo turno" : "Visualizza partita"}
                        </Button>
                      </div>
                    </Card.Body>
                  </Card>
                </Col>
              ))}
            </Row>
          ) : (
            <Card className="text-center mb-5">
              <Card.Body>
                <Card.Text>
                  Non hai partite attive al momento. Crea una nuova sfida o partecipa a una sfida esistente.
                </Card.Text>
              </Card.Body>
            </Card>
          )}
          
          {/* Crea Sfida */}
          <h2 className="mb-4 mt-5">Crea una Nuova Sfida</h2>
          <Card className="mb-5">
            <Card.Body>
              <Form onSubmit={handleCreateChallenge}>
                <Row>
                  <Col md={6}>
                    <Form.Group className="mb-3">
                      <Form.Label>Titolo della Sfida</Form.Label>
                      <Form.Control 
                        type="text" 
                        name="title"
                        value={newChallenge.title}
                        onChange={handleInputChange}
                        placeholder="Es. Torneo Amichevole"
                        required
                      />
                    </Form.Group>
                  </Col>
                  <Col md={6}>
                    <Form.Group className="mb-3">
                      <Form.Label>Tipo di Gioco</Form.Label>
                      <Form.Select 
                        name="gameType"
                        value={newChallenge.gameType}
                        onChange={handleInputChange}
                      >
                        <option value="prisoners-dilemma">Dilemma del Prigioniero</option>
                        <option value="hawk-dove" disabled>Hawk-Dove (Coming Soon)</option>
                        <option value="stag-hunt" disabled>Stag Hunt (Coming Soon)</option>
                        <option value="public-goods" disabled>Public Goods Game (Coming Soon)</option>
                      </Form.Select>
                    </Form.Group>
                  </Col>
                </Row>
                
                <Row>
                  <Col md={6}>
                    <Form.Group className="mb-3">
                      <Form.Label>Numero di Round</Form.Label>
                      <Form.Control 
                        type="number" 
                        name="rounds"
                        value={newChallenge.rounds}
                        onChange={handleInputChange}
                        min="1"
                        max="100"
                      />
                    </Form.Group>
                  </Col>
                  <Col md={6}>
                    <Form.Group className="mb-3">
                      <Form.Label>Descrizione</Form.Label>
                      <Form.Control 
                        as="textarea" 
                        rows={2}
                        name="description"
                        value={newChallenge.description}
                        onChange={handleInputChange}
                        placeholder="Descrivi brevemente la tua sfida"
                      />
                    </Form.Group>
                  </Col>
                </Row>
                
                <div className="text-center">
                  <Button type="submit" variant="primary">
                    Crea Sfida
                  </Button>
                </div>
              </Form>
              
              {challengeLink && (
                <div className="alert alert-success mt-4">
                  <p>Sfida creata con successo! Condividi questo link con i tuoi amici:</p>
                  <div className="input-group">
                    <input 
                      type="text" 
                      className="form-control" 
                      value={challengeLink} 
                      readOnly 
                    />
                    <Button 
                      variant="outline-secondary"
                      onClick={() => {
                        navigator.clipboard.writeText(challengeLink);
                        alert('Link copiato negli appunti!');
                      }}
                    >
                      Copia
                    </Button>
                  </div>
                </div>
              )}
            </Card.Body>
          </Card>
          
          {/* Sfide Disponibili */}
          <h2 className="mb-4">Sfide Disponibili</h2>
          {availableChallenges.length > 0 ? (
            <ListGroup className="mb-5">
              {availableChallenges.map(challenge => (
                <ListGroup.Item key={challenge.id} className="d-flex justify-content-between align-items-center">
                  <div>
                    <h5>{challenge.title}</h5>
                    <div className="text-muted">
                      Creata da: {challenge.creator} | Tipo: {challenge.gameType === 'prisoners-dilemma' ? 'Dilemma del Prigioniero' : challenge.gameType} | Round: {challenge.rounds}
                    </div>
                    <small>{challenge.description}</small>
                  </div>
                  <Button 
                    as={Link} 
                    to={`/multiplayer/join/${challenge.id}`}
                    variant="outline-primary"
                    size="sm"
                  >
                    Partecipa
                  </Button>
                </ListGroup.Item>
              ))}
            </ListGroup>
          ) : (
            <Card className="text-center mb-5">
              <Card.Body>
                <Card.Text>
                  Non ci sono sfide disponibili al momento. Crea una nuova sfida per iniziare!
                </Card.Text>
              </Card.Body>
            </Card>
          )}
          
          {/* Classifica */}
          <h2 className="mb-4">Classifica</h2>
          <Card>
            <Card.Body>
              <div className="table-responsive">
                <table className="table table-striped">
                  <thead>
                    <tr>
                      <th>#</th>
                      <th>Giocatore</th>
                      <th>Partite</th>
                      <th>Vittorie</th>
                      <th>Sconfitte</th>
                      <th>Punteggio</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>1</td>
                      <td>user777</td>
                      <td>42</td>
                      <td>35</td>
                      <td>7</td>
                      <td>1250</td>
                    </tr>
                    <tr>
                      <td>2</td>
                      <td>user555</td>
                      <td>38</td>
                      <td>29</td>
                      <td>9</td>
                      <td>1120</td>
                    </tr>
                    <tr>
                      <td>3</td>
                      <td>user999</td>
                      <td>25</td>
                      <td>18</td>
                      <td>7</td>
                      <td>980</td>
                    </tr>
                    <tr>
                      <td>4</td>
                      <td>user123</td>
                      <td>30</td>
                      <td>20</td>
                      <td>10</td>
                      <td>950</td>
                    </tr>
                    <tr>
                      <td>5</td>
                      <td>user456</td>
                      <td>22</td>
                      <td>15</td>
                      <td>7</td>
                      <td>890</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </Card.Body>
          </Card>
        </>
      )}
    </Container>
  );
};

export default Multiplayer;
