import React, { useState, useEffect } from 'react';
import { Container, Row, Col, Nav, Tab, Card, Button } from 'react-bootstrap';
import { Link, Routes, Route, useNavigate, useLocation } from 'react-router-dom';
import { fetchEducationalContent } from '../utils/api';

// Componenti per le sottosezioni
const History = () => {
  const [content, setContent] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadContent = async () => {
      try {
        const data = await fetchEducationalContent('history');
        setContent(data);
      } catch (error) {
        console.error('Errore nel caricamento dei contenuti storici:', error);
      } finally {
        setLoading(false);
      }
    };

    loadContent();
  }, []);

  if (loading) {
    return <div className="text-center py-5">Caricamento contenuti...</div>;
  }

  return (
    <div>
      <h2 className="mb-4">Storia della Teoria dei Giochi</h2>
      <div className="timeline-container">
        {content.map((item) => (
          <div key={item.id} className="timeline-item">
            <div className="timeline-content">
              <h4>{item.title}</h4>
              <p>{item.content}</p>
              <small>Pubblicato il: {new Date(item.date).toLocaleDateString()}</small>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

const Concepts = () => {
  const [content, setContent] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadContent = async () => {
      try {
        const data = await fetchEducationalContent('concepts');
        setContent(data);
      } catch (error) {
        console.error('Errore nel caricamento dei concetti:', error);
      } finally {
        setLoading(false);
      }
    };

    loadContent();
  }, []);

  if (loading) {
    return <div className="text-center py-5">Caricamento contenuti...</div>;
  }

  return (
    <div>
      <h2 className="mb-4">Concetti Fondamentali</h2>
      <Row>
        {content.map((item) => (
          <Col key={item.id} md={6} className="mb-4">
            <Card className="h-100">
              <Card.Body>
                <Card.Title>{item.title}</Card.Title>
                <Card.Text>{item.content}</Card.Text>
              </Card.Body>
              <Card.Footer>
                <small className="text-muted">Pubblicato il: {new Date(item.date).toLocaleDateString()}</small>
              </Card.Footer>
            </Card>
          </Col>
        ))}
      </Row>
    </div>
  );
};

const Applications = () => {
  const [content, setContent] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadContent = async () => {
      try {
        const data = await fetchEducationalContent('applications');
        setContent(data);
      } catch (error) {
        console.error('Errore nel caricamento delle applicazioni:', error);
      } finally {
        setLoading(false);
      }
    };

    loadContent();
  }, []);

  if (loading) {
    return <div className="text-center py-5">Caricamento contenuti...</div>;
  }

  return (
    <div>
      <h2 className="mb-4">Applicazioni nel Mondo Reale</h2>
      <div className="applications-container">
        {content.map((item) => (
          <Card key={item.id} className="mb-4">
            <Card.Body>
              <Card.Title>{item.title}</Card.Title>
              <Card.Text>{item.content}</Card.Text>
              <small className="text-muted">Pubblicato il: {new Date(item.date).toLocaleDateString()}</small>
            </Card.Body>
          </Card>
        ))}
      </div>
    </div>
  );
};

const Tutorials = () => {
  return (
    <div>
      <h2 className="mb-4">Tutorial</h2>
      <p className="lead">Impara la teoria dei giochi passo dopo passo con i nostri tutorial interattivi.</p>
      
      <Card className="mb-4">
        <Card.Body>
          <Card.Title>Introduzione alla Teoria dei Giochi</Card.Title>
          <Card.Text>
            Un tutorial base per comprendere i concetti fondamentali della teoria dei giochi e come applicarli.
          </Card.Text>
          <Button variant="primary">Inizia il Tutorial</Button>
        </Card.Body>
      </Card>
      
      <Card className="mb-4">
        <Card.Body>
          <Card.Title>Comprendere il Dilemma del Prigioniero</Card.Title>
          <Card.Text>
            Esplora in dettaglio il famoso Dilemma del Prigioniero e le sue implicazioni nella teoria dei giochi.
          </Card.Text>
          <Button variant="primary">Inizia il Tutorial</Button>
        </Card.Body>
      </Card>
      
      <Card className="mb-4">
        <Card.Body>
          <Card.Title>Strategie Evolutive</Card.Title>
          <Card.Text>
            Scopri come le strategie evolvono nel tempo e come questo concetto si applica in biologia ed economia.
          </Card.Text>
          <Button variant="primary">Inizia il Tutorial</Button>
        </Card.Body>
      </Card>
    </div>
  );
};

// Componente principale Educational
const Educational = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [activeKey, setActiveKey] = useState('history');

  useEffect(() => {
    const path = location.pathname.split('/').pop();
    if (path && path !== 'educational') {
      setActiveKey(path);
    } else {
      // Se siamo solo su /educational, impostiamo history come default
      setActiveKey('history');
    }
  }, [location]);

  const handleSelect = (key) => {
    setActiveKey(key);
    navigate(`/educational/${key}`);
  };

  return (
    <Container className="py-4">
      <h1 className="text-center mb-5">Risorse Educative</h1>
      
      <Tab.Container activeKey={activeKey} onSelect={handleSelect}>
        <Row>
          <Col md={3}>
            <Nav variant="pills" className="flex-column mb-4">
              <Nav.Item>
                <Nav.Link eventKey="history">Storia</Nav.Link>
              </Nav.Item>
              <Nav.Item>
                <Nav.Link eventKey="concepts">Concetti Fondamentali</Nav.Link>
              </Nav.Item>
              <Nav.Item>
                <Nav.Link eventKey="applications">Applicazioni</Nav.Link>
              </Nav.Item>
              <Nav.Item>
                <Nav.Link eventKey="tutorials">Tutorial</Nav.Link>
              </Nav.Item>
            </Nav>
          </Col>
          <Col md={9}>
            <Tab.Content>
              <Tab.Pane eventKey="history">
                <History />
              </Tab.Pane>
              <Tab.Pane eventKey="concepts">
                <Concepts />
              </Tab.Pane>
              <Tab.Pane eventKey="applications">
                <Applications />
              </Tab.Pane>
              <Tab.Pane eventKey="tutorials">
                <Tutorials />
              </Tab.Pane>
            </Tab.Content>
          </Col>
        </Row>
      </Tab.Container>
      
      <Routes>
        <Route path="/" element={<History />} />
        <Route path="/history" element={<History />} />
        <Route path="/concepts" element={<Concepts />} />
        <Route path="/applications" element={<Applications />} />
        <Route path="/tutorials" element={<Tutorials />} />
      </Routes>
    </Container>
  );
};

export default Educational;
