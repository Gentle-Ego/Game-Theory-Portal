import React, { useState, useEffect } from 'react';
import { Container, Row, Col, Card, Form, Button, Alert, Spinner } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';
import { getCurrentUser, updateProfile, logout } from '../utils/firebase';
import { useAppContext } from '../utils/AppContext';

const Profile = () => {
  const { user, setUser } = useAppContext();
  const navigate = useNavigate();
  
  const [displayName, setDisplayName] = useState('');
  const [bio, setBio] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [initialLoading, setInitialLoading] = useState(true);
  
  useEffect(() => {
    // Verifica se l'utente è autenticato
    const currentUser = getCurrentUser();
    if (!currentUser) {
      navigate('/login');
      return;
    }
    
    // Carica i dati del profilo
    setDisplayName(currentUser.displayName || '');
    setBio(currentUser.bio || '');
    setInitialLoading(false);
  }, [navigate]);
  
  const handleUpdateProfile = async (e) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    setLoading(true);
    
    try {
      // Aggiorna il profilo dell'utente
      await updateProfile(getCurrentUser(), {
        displayName,
        bio
      });
      
      // Aggiorna lo stato dell'utente nel contesto
      const updatedUser = getCurrentUser();
      setUser(updatedUser);
      
      setSuccess('Profilo aggiornato con successo!');
    } catch (err) {
      setError('Si è verificato un errore durante l\'aggiornamento del profilo. Riprova più tardi.');
      console.error(err);
    }
    
    setLoading(false);
  };
  
  const handleLogout = async () => {
    try {
      await logout();
      setUser(null);
      navigate('/');
    } catch (err) {
      setError('Si è verificato un errore durante il logout. Riprova più tardi.');
      console.error(err);
    }
  };
  
  if (initialLoading) {
    return (
      <Container className="py-5 text-center">
        <Spinner animation="border" role="status">
          <span className="visually-hidden">Caricamento...</span>
        </Spinner>
      </Container>
    );
  }
  
  return (
    <Container className="py-5">
      <Row className="justify-content-center">
        <Col md={8}>
          <Card className="shadow">
            <Card.Body className="p-4">
              <h2 className="text-center mb-4">Il Tuo Profilo</h2>
              
              {error && <Alert variant="danger">{error}</Alert>}
              {success && <Alert variant="success">{success}</Alert>}
              
              <Form onSubmit={handleUpdateProfile}>
                <Form.Group className="mb-3" controlId="displayName">
                  <Form.Label>Nome utente</Form.Label>
                  <Form.Control 
                    type="text" 
                    value={displayName}
                    onChange={(e) => setDisplayName(e.target.value)}
                    placeholder="Inserisci il tuo nome utente"
                    required
                  />
                </Form.Group>
                
                <Form.Group className="mb-3" controlId="email">
                  <Form.Label>Email</Form.Label>
                  <Form.Control 
                    type="email" 
                    value={user?.email || ''}
                    disabled
                    readOnly
                  />
                  <Form.Text className="text-muted">
                    L'email non può essere modificata.
                  </Form.Text>
                </Form.Group>
                
                <Form.Group className="mb-3" controlId="bio">
                  <Form.Label>Bio</Form.Label>
                  <Form.Control 
                    as="textarea" 
                    rows={3}
                    value={bio}
                    onChange={(e) => setBio(e.target.value)}
                    placeholder="Racconta qualcosa su di te..."
                  />
                </Form.Group>
                
                <div className="d-grid gap-2">
                  <Button 
                    variant="primary" 
                    type="submit"
                    disabled={loading}
                  >
                    {loading ? 'Aggiornamento in corso...' : 'Aggiorna Profilo'}
                  </Button>
                  
                  <Button 
                    variant="outline-danger" 
                    onClick={handleLogout}
                  >
                    Logout
                  </Button>
                </div>
              </Form>
            </Card.Body>
          </Card>
          
          <Card className="shadow mt-4">
            <Card.Body className="p-4">
              <h3 className="mb-3">Statistiche di Gioco</h3>
              
              <Row>
                <Col md={4} className="text-center mb-3">
                  <h4>Partite Giocate</h4>
                  <p className="display-4">0</p>
                </Col>
                <Col md={4} className="text-center mb-3">
                  <h4>Vittorie</h4>
                  <p className="display-4">0</p>
                </Col>
                <Col md={4} className="text-center mb-3">
                  <h4>Strategie Create</h4>
                  <p className="display-4">0</p>
                </Col>
              </Row>
            </Card.Body>
          </Card>
          
          <Card className="shadow mt-4">
            <Card.Body className="p-4">
              <h3 className="mb-3">Le Tue Strategie</h3>
              
              <p className="text-center text-muted">
                Non hai ancora creato nessuna strategia.
              </p>
              
              <div className="d-grid">
                <Button 
                  variant="outline-primary" 
                  onClick={() => navigate('/game-arena/strategy-builder')}
                >
                  Crea la Tua Prima Strategia
                </Button>
              </div>
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </Container>
  );
};

export default Profile;
