import React, { useState, useEffect } from 'react';
import { Container, Row, Col, Card, Button, Form, Nav, Tab, ListGroup } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import { useAppContext } from '../utils/AppContext';

const Community = () => {
  const { user } = useAppContext();
  const [discussions, setDiscussions] = useState([]);
  const [strategies, setStrategies] = useState([]);
  const [resources, setResources] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('discussions');
  const [newPost, setNewPost] = useState({
    title: '',
    content: '',
    category: 'general'
  });

  useEffect(() => {
    // Simulazione del caricamento dei dati
    setTimeout(() => {
      setDiscussions([
        {
          id: 1,
          title: 'Strategie ottimali nel Dilemma del Prigioniero iterato',
          author: 'user123',
          date: '2025-03-15T10:30:00Z',
          category: 'strategies',
          replies: 12,
          views: 145,
          content: 'Ho notato che in un Dilemma del Prigioniero iterato, la strategia Tit for Tat sembra essere molto efficace...'
        },
        {
          id: 2,
          title: 'Applicazioni della teoria dei giochi in economia',
          author: 'user456',
          date: '2025-03-18T14:45:00Z',
          category: 'applications',
          replies: 8,
          views: 98,
          content: 'Recentemente ho letto un articolo interessante su come la teoria dei giochi viene applicata nelle aste...'
        },
        {
          id: 3,
          title: 'Introduzione alla teoria dei giochi per principianti',
          author: 'user789',
          date: '2025-03-20T09:15:00Z',
          category: 'beginners',
          replies: 15,
          views: 210,
          content: 'Salve a tutti! Sono nuovo nel campo della teoria dei giochi e vorrei sapere da dove iniziare...'
        }
      ]);
      
      setStrategies([
        {
          id: 101,
          name: 'Tit for Tat Migliorato',
          author: 'user555',
          gameType: 'prisoners-dilemma',
          date: '2025-03-10T11:20:00Z',
          downloads: 78,
          rating: 4.5,
          description: 'Una versione migliorata di Tit for Tat che perdona occasionalmente.'
        },
        {
          id: 102,
          name: 'Pavlov Adattivo',
          author: 'user777',
          gameType: 'prisoners-dilemma',
          date: '2025-03-12T16:40:00Z',
          downloads: 45,
          rating: 4.2,
          description: 'Strategia Pavlov con adattamento basato sulla storia del gioco.'
        },
        {
          id: 103,
          name: 'Gradual',
          author: 'user999',
          gameType: 'prisoners-dilemma',
          date: '2025-03-14T08:55:00Z',
          downloads: 62,
          rating: 4.7,
          description: 'Strategia che aumenta gradualmente la punizione per i tradimenti.'
        }
      ]);
      
      setResources([
        {
          id: 201,
          title: 'Teoria dei Giochi: Un\'Introduzione',
          author: 'John Nash',
          type: 'paper',
          url: 'https://example.com/papers/game-theory-intro',
          date: '2024-10-15',
          description: 'Un\'introduzione completa alla teoria dei giochi e alle sue applicazioni.'
        },
        {
          id: 202,
          title: 'L\'Evoluzione della Cooperazione',
          author: 'Robert Axelrod',
          type: 'book',
          url: 'https://example.com/books/evolution-of-cooperation',
          date: '2024-08-22',
          description: 'Un classico sulla teoria dei giochi evolutiva e la cooperazione.'
        },
        {
          id: 203,
          title: 'Game Theory 101',
          author: 'William Spaniel',
          type: 'video',
          url: 'https://example.com/videos/game-theory-101',
          date: '2025-01-10',
          description: 'Serie di video educativi sui concetti base della teoria dei giochi.'
        }
      ]);
      
      setLoading(false);
    }, 1000);
  }, []);

  const handleNewPostSubmit = (e) => {
    e.preventDefault();
    
    // Simulazione dell'aggiunta di un nuovo post
    const newDiscussion = {
      id: Date.now(),
      title: newPost.title,
      author: user ? user.username : 'guest',
      date: new Date().toISOString(),
      category: newPost.category,
      replies: 0,
      views: 0,
      content: newPost.content
    };
    
    setDiscussions([newDiscussion, ...discussions]);
    
    // Reset del form
    setNewPost({
      title: '',
      content: '',
      category: 'general'
    });
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewPost({
      ...newPost,
      [name]: value
    });
  };

  if (loading) {
    return <div className="text-center py-5">Caricamento community hub...</div>;
  }

  return (
    <Container className="py-4">
      <h1 className="text-center mb-5">Community Hub</h1>
      
      <Tab.Container activeKey={activeTab} onSelect={(k) => setActiveTab(k)}>
        <Row>
          <Col md={3}>
            <Nav variant="pills" className="flex-column mb-4">
              <Nav.Item>
                <Nav.Link eventKey="discussions">Discussioni</Nav.Link>
              </Nav.Item>
              <Nav.Item>
                <Nav.Link eventKey="strategies">Strategie Condivise</Nav.Link>
              </Nav.Item>
              <Nav.Item>
                <Nav.Link eventKey="resources">Risorse</Nav.Link>
              </Nav.Item>
            </Nav>
            
            <Card className="mb-4">
              <Card.Body>
                <Card.Title>Community Stats</Card.Title>
                <ListGroup variant="flush">
                  <ListGroup.Item className="d-flex justify-content-between">
                    <span>Membri:</span>
                    <span>1,245</span>
                  </ListGroup.Item>
                  <ListGroup.Item className="d-flex justify-content-between">
                    <span>Discussioni:</span>
                    <span>387</span>
                  </ListGroup.Item>
                  <ListGroup.Item className="d-flex justify-content-between">
                    <span>Strategie:</span>
                    <span>156</span>
                  </ListGroup.Item>
                  <ListGroup.Item className="d-flex justify-content-between">
                    <span>Risorse:</span>
                    <span>89</span>
                  </ListGroup.Item>
                </ListGroup>
              </Card.Body>
            </Card>
          </Col>
          <Col md={9}>
            <Tab.Content>
              <Tab.Pane eventKey="discussions">
                <div className="d-flex justify-content-between align-items-center mb-4">
                  <h2>Discussioni</h2>
                  <Button 
                    variant="primary"
                    onClick={() => document.getElementById('new-post-form').scrollIntoView({ behavior: 'smooth' })}
                  >
                    Nuova Discussione
                  </Button>
                </div>
                
                <Card className="mb-4">
                  <Card.Body>
                    <Form.Group className="mb-3">
                      <Form.Control 
                        type="text" 
                        placeholder="Cerca nelle discussioni..." 
                      />
                    </Form.Group>
                    <div className="d-flex">
                      <Form.Select className="me-2" style={{ width: 'auto' }}>
                        <option value="all">Tutte le categorie</option>
                        <option value="general">Generale</option>
                        <option value="strategies">Strategie</option>
                        <option value="applications">Applicazioni</option>
                        <option value="beginners">Principianti</option>
                      </Form.Select>
                      <Form.Select style={{ width: 'auto' }}>
                        <option value="recent">Più recenti</option>
                        <option value="popular">Più popolari</option>
                        <option value="replies">Più risposte</option>
                      </Form.Select>
                    </div>
                  </Card.Body>
                </Card>
                
                <ListGroup className="mb-5">
                  {discussions.map(discussion => (
                    <ListGroup.Item key={discussion.id} className="d-flex justify-content-between align-items-start">
                      <div className="ms-2 me-auto">
                        <div className="fw-bold">
                          <Link to={`/community/discussion/${discussion.id}`} className="text-decoration-none">
                            {discussion.title}
                          </Link>
                        </div>
                        <div className="text-muted">
                          Pubblicato da {discussion.author} il {new Date(discussion.date).toLocaleDateString()}
                        </div>
                        <div className="mt-2">
                          {discussion.content.substring(0, 100)}...
                        </div>
                      </div>
                      <div className="text-end text-muted">
                        <div>{discussion.replies} risposte</div>
                        <div>{discussion.views} visualizzazioni</div>
                      </div>
                    </ListGroup.Item>
                  ))}
                </ListGroup>
                
                <Card id="new-post-form">
                  <Card.Body>
                    <Card.Title>Nuova Discussione</Card.Title>
                    {user ? (
                      <Form onSubmit={handleNewPostSubmit}>
                        <Form.Group className="mb-3">
                          <Form.Label>Titolo</Form.Label>
                          <Form.Control 
                            type="text" 
                            name="title"
                            value={newPost.title}
                            onChange={handleInputChange}
                            placeholder="Inserisci il titolo della discussione"
                            required
                          />
                        </Form.Group>
                        
                        <Form.Group className="mb-3">
                          <Form.Label>Categoria</Form.Label>
                          <Form.Select 
                            name="category"
                            value={newPost.category}
                            onChange={handleInputChange}
                          >
                            <option value="general">Generale</option>
                            <option value="strategies">Strategie</option>
                            <option value="applications">Applicazioni</option>
                            <option value="beginners">Principianti</option>
                          </Form.Select>
                        </Form.Group>
                        
                        <Form.Group className="mb-3">
                          <Form.Label>Contenuto</Form.Label>
                          <Form.Control 
                            as="textarea" 
                            rows={5}
                            name="content"
                            value={newPost.content}
                            onChange={handleInputChange}
                            placeholder="Scrivi il contenuto della tua discussione"
                            required
                          />
                        </Form.Group>
                        
                        <Button type="submit" variant="primary">
                          Pubblica Discussione
                        </Button>
                      </Form>
                    ) : (
                      <div className="text-center py-3">
                        <p>Devi effettuare l'accesso per pubblicare una discussione.</p>
                        <Button as={Link} to="/login" variant="primary" className="me-2">Accedi</Button>
                        <Button as={Link} to="/register" variant="outline-primary">Registrati</Button>
                      </div>
                    )}
                  </Card.Body>
                </Card>
              </Tab.Pane>
              
              <Tab.Pane eventKey="strategies">
                <div className="d-flex justify-content-between align-items-center mb-4">
                  <h2>Strategie Condivise</h2>
                  <Button as={Link} to="/game-arena/strategy-builder" variant="primary">
                    Crea Strategia
                  </Button>
                </div>
                
                <Card className="mb-4">
                  <Card.Body>
                    <Form.Group className="mb-3">
                      <Form.Control 
                        type="text" 
                        placeholder="Cerca strategie..." 
                      />
                    </Form.Group>
                    <div className="d-flex">
                      <Form.Select className="me-2" style={{ width: 'auto' }}>
                        <option value="all">Tutti i giochi</option>
                        <option value="prisoners-dilemma">Dilemma del Prigioniero</option>
                        <option value="hawk-dove">Hawk-Dove</option>
                        <option value="stag-hunt">Stag Hunt</option>
                        <option value="public-goods">Public Goods</option>
                      </Form.Select>
                      <Form.Select style={{ width: 'auto' }}>
                        <option value="recent">Più recenti</option>
                        <option value="popular">Più popolari</option>
                        <option value="rating">Miglior valutazione</option>
                      </Form.Select>
                    </div>
                  </Card.Body>
                </Card>
                
                <Row>
                  {strategies.map(strategy => (
                    <Col md={6} lg={4} key={strategy.id} className="mb-4">
                      <Card className="h-100">
                        <Card.Body>
                          <Card.Title>{strategy.name}</Card.Title>
                          <Card.Subtitle className="mb-2 text-muted">
                            di {strategy.author}
                          </Card.Subtitle>
                          <div className="my-3">
                            <div className="d-flex justify-content-between">
                              <div>Gioco:</div>
                              <div>
                                {strategy.gameType === 'prisoners-dilemma' ? 'Dilemma del Prigioniero' : strategy.gameType}
                              </div>
                            </div>
                            <div className="d-flex justify-content-between">
                              <div>Download:</div>
                              <div>{strategy.downloads}</div>
                            </div>
                            <div className="d-flex justify-content-between">
                              <div>Valutazione:</div>
                              <div>
                                {Array.from({ length: 5 }).map((_, i) => (
                                  <i 
                                    key={i}
                                    className={`fas fa-star ${i < Math.floor(strategy.rating) ? 'text-warning' : 'text-muted'}`}
                                  ></i>
                                ))}
                                {' '}{strategy.rating}
                              </div>
                            </div>
                          </div>
                          <Card.Text>{strategy.description}</Card.Text>
                        </Card.Body>
                        <Card.Footer>
                          <Button 
                            as={Link} 
                            to={`/community/strategy/${strategy.id}`}
                            variant="outline-primary"
                            size="sm"
                            className="w-100"
                          >
                            Visualizza Dettagli
                          </Button>
                        </Card.Footer>
                      </Card>
                    </Col>
                  ))}
                </Row>
              </Tab.Pane>
              
              <Tab.Pane eventKey="resources">
                <h2 className="mb-4">Risorse</h2>
                
                <Card className="mb-4">
                  <Card.Body>
                    <Form.Group className="mb-3">
                      <Form.Control 
                        type="text" 
                        placeholder="Cerca risorse..." 
                      />
                    </Form.Group>
                    <div className="d-flex">
                      <Form.Select className="me-2" style={{ width: 'auto' }}>
                        <option value="all">Tutti i tipi</option>
                        <option value="paper">Paper Accademici</option>
                        <option value="book">Libri</option>
                        <option value="video">Video</option>
                        <option value="course">Corsi</option>
                      </Form.Select>
                      <Form.Select style={{ width: 'auto' }}>
                        <option value="recent">Più recenti</option>
                        <option value="popular">Più popolari</option>
                      </Form.Select>
                    </div>
                  </Card.Body>
                </Card>
                
                <ListGroup className="mb-5">
                  {resources.map(resource => (
                    <ListGroup.Item key={resource.id} className="d-flex justify-content-between align-items-start">
                      <div className="ms-2 me-auto">
                        <div className="fw-bold">
                          <a href={resource.url} target="_blank" rel="noopener noreferrer" className="text-decoration-none">
                            {resource.title}
                          </a>
                        </div>
                        <div className="text-muted">
                          di {resource.author} | {resource.date}
                        </div>
                        <div className="mt-2">
                          {resource.description}
                        </div>
                      </div>
                      <div className="ms-3">
                        <span className="badge bg-primary rounded-pill text-uppercase">
                          {resource.type}
                        </span>
                      </div>
                    </ListGroup.Item>
                  ))}
                </ListGroup>
                
                <Card>
                  <Card.Body>
                    <Card.Title>Suggerisci una Risorsa</Card.Title>
                    {user ? (
                      <Form>
                        <Row>
                          <Col md={6}>
                            <Form.Group className="mb-3">
                              <Form.Label>Titolo</Form.Label>
                              <Form.Control 
                                type="text" 
                                placeholder="Titolo della risorsa"
                                required
                              />
                            </Form.Group>
                          </Col>
                          <Col md={6}>
                            <Form.Group className="mb-3">
                              <Form.Label>Autore</Form.Label>
                              <Form.Control 
                                type="text" 
                                placeholder="Autore della risorsa"
                                required
                              />
                            </Form.Group>
                          </Col>
                        </Row>
                        
                        <Row>
                          <Col md={6}>
                            <Form.Group className="mb-3">
                              <Form.Label>URL</Form.Label>
                              <Form.Control 
                                type="url" 
                                placeholder="https://example.com/resource"
                                required
                              />
                            </Form.Group>
                          </Col>
                          <Col md={6}>
                            <Form.Group className="mb-3">
                              <Form.Label>Tipo</Form.Label>
                              <Form.Select required>
                                <option value="">Seleziona un tipo</option>
                                <option value="paper">Paper Accademico</option>
                                <option value="book">Libro</option>
                                <option value="video">Video</option>
                                <option value="course">Corso</option>
                              </Form.Select>
                            </Form.Group>
                          </Col>
                        </Row>
                        
                        <Form.Group className="mb-3">
                          <Form.Label>Descrizione</Form.Label>
                          <Form.Control 
                            as="textarea" 
                            rows={3}
                            placeholder="Breve descrizione della risorsa"
                            required
                          />
                        </Form.Group>
                        
                        <Button type="submit" variant="primary">
                          Suggerisci Risorsa
                        </Button>
                      </Form>
                    ) : (
                      <div className="text-center py-3">
                        <p>Devi effettuare l'accesso per suggerire una risorsa.</p>
                        <Button as={Link} to="/login" variant="primary" className="me-2">Accedi</Button>
                        <Button as={Link} to="/register" variant="outline-primary">Registrati</Button>
                      </div>
                    )}
                  </Card.Body>
                </Card>
              </Tab.Pane>
            </Tab.Content>
          </Col>
        </Row>
      </Tab.Container>
    </Container>
  );
};

export default Community;
