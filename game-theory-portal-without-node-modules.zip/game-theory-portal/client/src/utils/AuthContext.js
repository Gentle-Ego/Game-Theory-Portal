import React, { createContext, useState, useContext, useEffect } from 'react';
import { onAuthStateChange, getCurrentUser } from './firebase';

// Creazione del contesto per l'autenticazione
const AuthContext = createContext();

// Hook personalizzato per utilizzare il contesto di autenticazione
export const useAuth = () => useContext(AuthContext);

// Provider del contesto di autenticazione
export const AuthProvider = ({ children }) => {
  const [currentUser, setCurrentUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Ascolta i cambiamenti dello stato di autenticazione
    const unsubscribe = onAuthStateChange((user) => {
      setCurrentUser(user);
      setLoading(false);
    });

    // Pulizia dell'effetto
    return unsubscribe;
  }, []);

  // Verifica se l'utente ha un ruolo specifico
  const hasRole = (role) => {
    if (!currentUser) return false;
    
    // Implementazione semplificata: in un'applicazione reale, 
    // i ruoli sarebbero memorizzati in un database
    const userRoles = currentUser.roles || [];
    return userRoles.includes(role);
  };

  // Verifica se l'utente è autenticato
  const isAuthenticated = () => {
    return !!currentUser;
  };

  // Valore del contesto
  const value = {
    currentUser,
    loading,
    hasRole,
    isAuthenticated
  };

  return (
    <AuthContext.Provider value={value}>
      {!loading && children}
    </AuthContext.Provider>
  );
};

// Componente HOC per proteggere le route che richiedono autenticazione
export const withAuth = (Component) => {
  return function ProtectedRoute(props) {
    const { currentUser, loading } = useAuth();
    
    if (loading) {
      return <div>Caricamento...</div>;
    }
    
    if (!currentUser) {
      // Reindirizza alla pagina di login
      window.location.href = '/login';
      return null;
    }
    
    return <Component {...props} />;
  };
};

// Componente HOC per proteggere le route che richiedono un ruolo specifico
export const withRole = (roles) => (Component) => {
  return function RoleProtectedRoute(props) {
    const { currentUser, loading, hasRole } = useAuth();
    
    if (loading) {
      return <div>Caricamento...</div>;
    }
    
    if (!currentUser) {
      // Reindirizza alla pagina di login
      window.location.href = '/login';
      return null;
    }
    
    // Verifica se l'utente ha almeno uno dei ruoli richiesti
    const hasRequiredRole = Array.isArray(roles)
      ? roles.some(role => hasRole(role))
      : hasRole(roles);
    
    if (!hasRequiredRole) {
      // Reindirizza alla pagina di accesso negato
      window.location.href = '/access-denied';
      return null;
    }
    
    return <Component {...props} />;
  };
};

export default AuthContext;
