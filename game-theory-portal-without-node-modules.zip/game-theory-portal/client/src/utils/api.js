// API per la gestione delle strategie di gioco
export const fetchStrategies = async () => {
  // In una versione reale, questa funzione farebbe una chiamata a un'API esterna
  // Per ora, restituiamo dati di esempio
  return [
    {
      id: 1,
      name: 'Tit for Tat',
      description: 'Coopera al primo turno, poi replica la mossa dell\'avversario nel turno precedente.',
      code: 'function titForTat(history) {\n  if (history.length === 0) return "cooperate";\n  return history[history.length - 1].opponent;\n}',
      author: 'Sistema',
      category: 'Classica'
    },
    {
      id: 2,
      name: 'Always Defect',
      description: 'Tradisce sempre, indipendentemente dalla storia del gioco.',
      code: 'function alwaysDefect() {\n  return "defect";\n}',
      author: 'Sistema',
      category: 'Classica'
    },
    {
      id: 3,
      name: 'Always Cooperate',
      description: 'Coopera sempre, indipendentemente dalla storia del gioco.',
      code: 'function alwaysCooperate() {\n  return "cooperate";\n}',
      author: 'Sistema',
      category: 'Classica'
    }
  ];
};

export const saveStrategy = async (strategy) => {
  // In una versione reale, questa funzione salverebbe la strategia in un database
  // Per ora, simuliamo un'operazione di salvataggio
  console.log('Strategia salvata:', strategy);
  return {
    ...strategy,
    id: Date.now(), // Genera un ID unico basato sul timestamp
    author: 'Utente'
  };
};

// API per la gestione dei giochi
export const fetchGames = async () => {
  // In una versione reale, questa funzione farebbe una chiamata a un'API esterna
  // Per ora, restituiamo dati di esempio
  return [
    {
      id: 1,
      name: 'Dilemma del Prigioniero',
      description: 'Un classico gioco di teoria dei giochi in cui due giocatori devono decidere se cooperare o tradire.',
      type: 'matrix',
      payoffMatrix: {
        cooperate: {
          cooperate: [3, 3],
          defect: [0, 5]
        },
        defect: {
          cooperate: [5, 0],
          defect: [1, 1]
        }
      }
    },
    {
      id: 2,
      name: 'Hawk-Dove',
      description: 'Un gioco che modella il conflitto tra comportamenti aggressivi e pacifici.',
      type: 'matrix',
      payoffMatrix: {
        hawk: {
          hawk: [-2, -2],
          dove: [4, 0]
        },
        dove: {
          hawk: [0, 4],
          dove: [2, 2]
        }
      }
    },
    {
      id: 3,
      name: 'Stag Hunt',
      description: 'Un gioco che modella il conflitto tra sicurezza e cooperazione sociale.',
      type: 'matrix',
      payoffMatrix: {
        stag: {
          stag: [4, 4],
          hare: [0, 3]
        },
        hare: {
          stag: [3, 0],
          hare: [2, 2]
        }
      }
    }
  ];
};

// API per la gestione dei tornei
export const createTournament = async (tournamentData) => {
  // In una versione reale, questa funzione creerebbe un torneo in un database
  // Per ora, simuliamo un'operazione di creazione
  console.log('Torneo creato:', tournamentData);
  return {
    ...tournamentData,
    id: Date.now(), // Genera un ID unico basato sul timestamp
    status: 'created',
    date: new Date().toISOString()
  };
};

// API per la gestione degli utenti (da integrare con Firebase Authentication)
export const getUserProfile = async (userId) => {
  // In una versione reale, questa funzione recupererebbe il profilo utente da Firebase
  // Per ora, restituiamo dati di esempio
  return {
    id: userId,
    username: 'user123',
    email: 'user@example.com',
    createdAt: '2025-01-01T00:00:00Z',
    stats: {
      gamesPlayed: 42,
      wins: 28,
      losses: 10,
      draws: 4
    }
  };
};

// API per la gestione dei contenuti educativi
export const fetchEducationalContent = async (category) => {
  // In una versione reale, questa funzione recupererebbe i contenuti educativi da un database
  // Per ora, restituiamo dati di esempio
  const allContent = {
    history: [
      {
        id: 1,
        title: 'Le origini della teoria dei giochi',
        content: 'La teoria dei giochi ha le sue radici nel lavoro di John von Neumann negli anni \'20...',
        author: 'Sistema',
        date: '2025-01-01T00:00:00Z'
      },
      {
        id: 2,
        title: 'John Nash e l\'equilibrio di Nash',
        content: 'John Nash ha rivoluzionato la teoria dei giochi con il concetto di equilibrio...',
        author: 'Sistema',
        date: '2025-01-02T00:00:00Z'
      }
    ],
    concepts: [
      {
        id: 3,
        title: 'Strategie dominanti',
        content: 'Una strategia dominante è una strategia che è sempre la migliore risposta...',
        author: 'Sistema',
        date: '2025-01-03T00:00:00Z'
      },
      {
        id: 4,
        title: 'Equilibrio di Nash',
        content: 'L\'equilibrio di Nash è una situazione in cui nessun giocatore può migliorare...',
        author: 'Sistema',
        date: '2025-01-04T00:00:00Z'
      }
    ],
    applications: [
      {
        id: 5,
        title: 'Teoria dei giochi in economia',
        content: 'La teoria dei giochi ha numerose applicazioni in economia, come...',
        author: 'Sistema',
        date: '2025-01-05T00:00:00Z'
      },
      {
        id: 6,
        title: 'Teoria dei giochi in biologia',
        content: 'In biologia, la teoria dei giochi è utilizzata per modellare l\'evoluzione...',
        author: 'Sistema',
        date: '2025-01-06T00:00:00Z'
      }
    ]
  };
  
  return category ? allContent[category] || [] : allContent;
};
