import { initializeApp } from 'firebase/app';
import { getFirestore, doc, setDoc, getDoc, updateDoc, collection, query, where, getDocs } from 'firebase/firestore';
import { getCurrentUser } from './firebase';

// La configurazione di Firebase dovrebbe essere la stessa di firebase.js
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "game-theory-portal.firebaseapp.com",
  projectId: "game-theory-portal",
  storageBucket: "game-theory-portal.appspot.com",
  messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
  appId: "YOUR_APP_ID"
};

// Inizializza Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

/**
 * Crea o aggiorna il profilo utente nel database
 * @param {object} userData - Dati dell'utente da salvare
 * @returns {Promise} - Promise che si risolve con il risultato dell'operazione
 */
export const saveUserProfile = async (userData) => {
  try {
    const user = getCurrentUser();
    if (!user) throw new Error('Utente non autenticato');
    
    const userRef = doc(db, 'users', user.uid);
    
    // Verifica se il documento esiste già
    const docSnap = await getDoc(userRef);
    
    if (docSnap.exists()) {
      // Aggiorna il documento esistente
      await updateDoc(userRef, {
        ...userData,
        updatedAt: new Date()
      });
    } else {
      // Crea un nuovo documento
      await setDoc(userRef, {
        ...userData,
        uid: user.uid,
        email: user.email,
        displayName: user.displayName || userData.displayName || '',
        createdAt: new Date(),
        updatedAt: new Date()
      });
    }
    
    return { success: true };
  } catch (error) {
    console.error('Errore nel salvataggio del profilo utente:', error);
    return { success: false, error: error.message };
  }
};

/**
 * Ottiene il profilo utente dal database
 * @param {string} userId - ID dell'utente (opzionale, se non fornito usa l'utente corrente)
 * @returns {Promise} - Promise che si risolve con i dati dell'utente
 */
export const getUserProfile = async (userId = null) => {
  try {
    const user = userId ? { uid: userId } : getCurrentUser();
    if (!user) throw new Error('Utente non autenticato');
    
    const userRef = doc(db, 'users', user.uid);
    const docSnap = await getDoc(userRef);
    
    if (docSnap.exists()) {
      return { success: true, data: docSnap.data() };
    } else {
      return { success: false, error: 'Profilo utente non trovato' };
    }
  } catch (error) {
    console.error('Errore nel recupero del profilo utente:', error);
    return { success: false, error: error.message };
  }
};

/**
 * Salva una strategia creata dall'utente
 * @param {object} strategyData - Dati della strategia
 * @returns {Promise} - Promise che si risolve con il risultato dell'operazione
 */
export const saveUserStrategy = async (strategyData) => {
  try {
    const user = getCurrentUser();
    if (!user) throw new Error('Utente non autenticato');
    
    const strategyRef = doc(collection(db, 'strategies'));
    
    await setDoc(strategyRef, {
      ...strategyData,
      id: strategyRef.id,
      authorId: user.uid,
      authorName: user.displayName || 'Utente anonimo',
      createdAt: new Date(),
      updatedAt: new Date(),
      downloads: 0,
      rating: 0,
      ratingCount: 0
    });
    
    return { success: true, strategyId: strategyRef.id };
  } catch (error) {
    console.error('Errore nel salvataggio della strategia:', error);
    return { success: false, error: error.message };
  }
};

/**
 * Ottiene le strategie create dall'utente
 * @param {string} userId - ID dell'utente (opzionale, se non fornito usa l'utente corrente)
 * @returns {Promise} - Promise che si risolve con le strategie dell'utente
 */
export const getUserStrategies = async (userId = null) => {
  try {
    const user = userId ? { uid: userId } : getCurrentUser();
    if (!user) throw new Error('Utente non autenticato');
    
    const strategiesQuery = query(
      collection(db, 'strategies'),
      where('authorId', '==', user.uid)
    );
    
    const querySnapshot = await getDocs(strategiesQuery);
    const strategies = [];
    
    querySnapshot.forEach((doc) => {
      strategies.push(doc.data());
    });
    
    return { success: true, strategies };
  } catch (error) {
    console.error('Errore nel recupero delle strategie dell\'utente:', error);
    return { success: false, error: error.message };
  }
};

/**
 * Salva i risultati di una partita
 * @param {object} gameData - Dati della partita
 * @returns {Promise} - Promise che si risolve con il risultato dell'operazione
 */
export const saveGameResult = async (gameData) => {
  try {
    const user = getCurrentUser();
    if (!user) throw new Error('Utente non autenticato');
    
    const gameRef = doc(collection(db, 'games'));
    
    await setDoc(gameRef, {
      ...gameData,
      id: gameRef.id,
      userId: user.uid,
      timestamp: new Date()
    });
    
    // Aggiorna le statistiche dell'utente
    const userRef = doc(db, 'users', user.uid);
    const userDoc = await getDoc(userRef);
    
    if (userDoc.exists()) {
      const userData = userDoc.data();
      const stats = userData.stats || {
        gamesPlayed: 0,
        wins: 0,
        losses: 0,
        draws: 0
      };
      
      stats.gamesPlayed += 1;
      
      if (gameData.result === 'win') {
        stats.wins += 1;
      } else if (gameData.result === 'loss') {
        stats.losses += 1;
      } else if (gameData.result === 'draw') {
        stats.draws += 1;
      }
      
      await updateDoc(userRef, { stats });
    }
    
    return { success: true, gameId: gameRef.id };
  } catch (error) {
    console.error('Errore nel salvataggio dei risultati della partita:', error);
    return { success: false, error: error.message };
  }
};

/**
 * Ottiene la cronologia delle partite dell'utente
 * @param {string} userId - ID dell'utente (opzionale, se non fornito usa l'utente corrente)
 * @param {number} limit - Numero massimo di risultati da restituire
 * @returns {Promise} - Promise che si risolve con la cronologia delle partite
 */
export const getUserGameHistory = async (userId = null, limit = 10) => {
  try {
    const user = userId ? { uid: userId } : getCurrentUser();
    if (!user) throw new Error('Utente non autenticato');
    
    const gamesQuery = query(
      collection(db, 'games'),
      where('userId', '==', user.uid)
    );
    
    const querySnapshot = await getDocs(gamesQuery);
    const games = [];
    
    querySnapshot.forEach((doc) => {
      games.push(doc.data());
    });
    
    // Ordina per timestamp decrescente e limita il numero di risultati
    return { 
      success: true, 
      games: games
        .sort((a, b) => b.timestamp.toDate() - a.timestamp.toDate())
        .slice(0, limit) 
    };
  } catch (error) {
    console.error('Errore nel recupero della cronologia delle partite:', error);
    return { success: false, error: error.message };
  }
};

export default db;
