// Configurazione di Firebase per l'autenticazione
import { initializeApp } from 'firebase/app';
import { 
  getAuth, 
  createUserWithEmailAndPassword, 
  signInWithEmailAndPassword, 
  signOut, 
  onAuthStateChanged,
  updateProfile,
  sendPasswordResetEmail,
  GoogleAuthProvider,
  signInWithPopup,
  GithubAuthProvider
} from 'firebase/auth';

// La configurazione di Firebase dovrebbe essere sostituita con i valori reali
// quando il progetto viene effettivamente implementato
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "game-theory-portal.firebaseapp.com",
  projectId: "game-theory-portal",
  storageBucket: "game-theory-portal.appspot.com",
  messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
  appId: "YOUR_APP_ID"
};

// Inizializza Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

// Provider per l'autenticazione con servizi esterni
const googleProvider = new GoogleAuthProvider();
const githubProvider = new GithubAuthProvider();

// Funzione per la registrazione con email e password
export const registerWithEmailAndPassword = async (email, password, displayName) => {
  try {
    const userCredential = await createUserWithEmailAndPassword(auth, email, password);
    const user = userCredential.user;
    
    // Aggiorna il profilo utente con il nome visualizzato
    await updateProfile(user, {
      displayName: displayName
    });
    
    return { success: true, user };
  } catch (error) {
    return { success: false, error: error.message };
  }
};

// Funzione per il login con email e password
export const loginWithEmailAndPassword = async (email, password) => {
  try {
    const userCredential = await signInWithEmailAndPassword(auth, email, password);
    return { success: true, user: userCredential.user };
  } catch (error) {
    return { success: false, error: error.message };
  }
};

// Funzione per il login con Google
export const loginWithGoogle = async () => {
  try {
    const result = await signInWithPopup(auth, googleProvider);
    return { success: true, user: result.user };
  } catch (error) {
    return { success: false, error: error.message };
  }
};

// Funzione per il login con GitHub
export const loginWithGithub = async () => {
  try {
    const result = await signInWithPopup(auth, githubProvider);
    return { success: true, user: result.user };
  } catch (error) {
    return { success: false, error: error.message };
  }
};

// Funzione per il logout
export const logout = async () => {
  try {
    await signOut(auth);
    return { success: true };
  } catch (error) {
    return { success: false, error: error.message };
  }
};

// Funzione per il reset della password
export const resetPassword = async (email) => {
  try {
    await sendPasswordResetEmail(auth, email);
    return { success: true };
  } catch (error) {
    return { success: false, error: error.message };
  }
};

// Funzione per ottenere l'utente corrente
export const getCurrentUser = () => {
  return auth.currentUser;
};

// Funzione per ascoltare i cambiamenti dello stato di autenticazione
export const onAuthStateChange = (callback) => {
  return onAuthStateChanged(auth, callback);
};

export default auth;
