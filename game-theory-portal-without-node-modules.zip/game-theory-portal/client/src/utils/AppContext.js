import React, { createContext, useContext, useState } from 'react';

// Creazione del Context
const AppContext = createContext();

// Provider Component
export const AppProvider = ({ children }) => {
  // State per l'autenticazione dell'utente
  const [user, setUser] = useState(null);
  
  // State per le strategie di gioco
  const [strategies, setStrategies] = useState([]);
  
  // State per i giochi attivi
  const [activeGames, setActiveGames] = useState([]);
  
  // Funzioni per gestire l'autenticazione
  const login = (userData) => {
    setUser(userData);
  };
  
  const logout = () => {
    setUser(null);
  };
  
  // Funzioni per gestire le strategie
  const addStrategy = (strategy) => {
    setStrategies([...strategies, strategy]);
  };
  
  const removeStrategy = (strategyId) => {
    setStrategies(strategies.filter(s => s.id !== strategyId));
  };
  
  // Funzioni per gestire i giochi
  const startGame = (game) => {
    setActiveGames([...activeGames, game]);
  };
  
  const endGame = (gameId) => {
    setActiveGames(activeGames.filter(g => g.id !== gameId));
  };
  
  // Valori e funzioni da condividere attraverso il Context
  const value = {
    user,
    strategies,
    activeGames,
    login,
    logout,
    addStrategy,
    removeStrategy,
    startGame,
    endGame
  };
  
  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
};

// Hook personalizzato per utilizzare il Context
export const useAppContext = () => {
  return useContext(AppContext);
};
