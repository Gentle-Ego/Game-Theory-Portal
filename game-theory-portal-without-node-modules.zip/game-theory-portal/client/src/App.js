import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import './styles/App.css';

// Layout Components
import Header from './components/layout/Header';
import Footer from './components/layout/Footer';

// Page Components
import Home from './pages/Home';
import Educational from './pages/Educational';
import GameArena from './pages/GameArena';
import Multiplayer from './pages/Multiplayer';
import Community from './pages/Community';
import NotFound from './pages/NotFound';

function App() {
  return (
    <Router>
      <div className="App">
        <Header />
        <main className="container py-4">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/educational/*" element={<Educational />} />
            <Route path="/game-arena/*" element={<GameArena />} />
            <Route path="/multiplayer/*" element={<Multiplayer />} />
            <Route path="/community/*" element={<Community />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </main>
        <Footer />
      </div>
    </Router>
  );
}

export default App;
