import React from 'react';
import { Container } from 'react-bootstrap';

const Footer = () => {
  return (
    <footer className="bg-dark text-light py-4 mt-5">
      <Container>
        <div className="row">
          <div className="col-md-6">
            <h5>Game Theory Portal</h5>
            <p>Una piattaforma educativa e interattiva dedicata alla teoria dei giochi.</p>
          </div>
          <div className="col-md-3">
            <h5>Link Utili</h5>
            <ul className="list-unstyled">
              <li><a href="/educational" className="text-light">Risorse Educative</a></li>
              <li><a href="/game-arena" className="text-light">Arena di Gioco</a></li>
              <li><a href="/community" className="text-light">Community</a></li>
            </ul>
          </div>
          <div className="col-md-3">
            <h5>Progetto</h5>
            <ul className="list-unstyled">
              <li><a href="https://github.com" className="text-light">GitHub</a></li>
              <li><a href="/about" className="text-light">Chi Siamo</a></li>
              <li><a href="/contact" className="text-light">Contatti</a></li>
            </ul>
          </div>
        </div>
        <hr />
        <div className="text-center">
          <p>&copy; {new Date().getFullYear()} Game Theory Portal. Tutti i diritti riservati.</p>
          <p>Realizzato con tecnologie open source.</p>
        </div>
      </Container>
    </footer>
  );
};

export default Footer;
