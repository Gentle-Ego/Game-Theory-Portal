# Basi Matematiche della Teoria dei Giochi

## Rappresentazione Formale dei Giochi

### Forma Normale (o Strategica)

La forma normale è una rappresentazione matematica di un gioco che specifica:

- L'insieme dei giocatori: $N = \{1, 2, \ldots, n\}$
- L'insieme delle strategie disponibili per ciascun giocatore: $S_i$ per il giocatore $i$
- Le funzioni di payoff per ciascun giocatore: $u_i: S_1 \times S_2 \times \ldots \times S_n \rightarrow \mathbb{R}$

Formalmente, un gioco in forma normale è una tripla $G = (N, S, u)$ dove:
- $N$ è l'insieme dei giocatori
- $S = S_1 \times S_2 \times \ldots \times S_n$ è lo spazio delle strategie
- $u = (u_1, u_2, \ldots, u_n)$ è il vettore delle funzioni di payoff

Per un gioco a due giocatori con strategie finite, la forma normale è spesso rappresentata come una matrice dei payoff.

### Forma Estensiva

La forma estensiva rappresenta un gioco come un albero, dove:
- I nodi rappresentano punti decisionali
- I rami rappresentano le possibili azioni
- I nodi terminali rappresentano i payoff

Formalmente, un gioco in forma estensiva è una tupla $\Gamma = (N, A, H, Z, \chi, \rho, \sigma, u)$ dove:
- $N$ è l'insieme dei giocatori
- $A$ è l'insieme delle azioni
- $H$ è l'insieme delle storie (sequenze di azioni)
- $Z \subset H$ è l'insieme delle storie terminali
- $\chi: H \setminus Z \rightarrow N$ assegna a ogni storia non terminale il giocatore che deve muovere
- $\rho: H \setminus Z \rightarrow 2^A$ specifica le azioni disponibili dopo ogni storia non terminale
- $\sigma$ rappresenta l'informazione disponibile ai giocatori
- $u = (u_1, u_2, \ldots, u_n)$ dove $u_i: Z \rightarrow \mathbb{R}$ è la funzione di payoff per il giocatore $i$

## Strategie e Equilibri

### Strategie Pure e Miste

Una **strategia pura** è una scelta deterministica di un'azione.

Una **strategia mista** è una distribuzione di probabilità sulle strategie pure. Per un giocatore $i$ con strategie pure $S_i = \{s_1, s_2, \ldots, s_m\}$, una strategia mista è un vettore $\sigma_i = (\sigma_i(s_1), \sigma_i(s_2), \ldots, \sigma_i(s_m))$ dove:
- $\sigma_i(s_j) \geq 0$ per ogni $j$
- $\sum_{j=1}^{m} \sigma_i(s_j) = 1$

Il payoff atteso di un profilo di strategie miste $\sigma = (\sigma_1, \sigma_2, \ldots, \sigma_n)$ per il giocatore $i$ è:

$$E[u_i(\sigma)] = \sum_{s \in S} \left( \prod_{j=1}^{n} \sigma_j(s_j) \right) u_i(s)$$

### Equilibrio di Nash

Un profilo di strategie $s^* = (s_1^*, s_2^*, \ldots, s_n^*)$ è un **equilibrio di Nash** se per ogni giocatore $i$ e ogni strategia alternativa $s_i$:

$$u_i(s_i^*, s_{-i}^*) \geq u_i(s_i, s_{-i}^*)$$

dove $s_{-i}^*$ rappresenta le strategie di tutti i giocatori tranne $i$.

In altre parole, nessun giocatore può migliorare il proprio payoff cambiando unilateralmente la propria strategia.

Per le strategie miste, un profilo $\sigma^* = (\sigma_1^*, \sigma_2^*, \ldots, \sigma_n^*)$ è un equilibrio di Nash se:

$$E[u_i(\sigma_i^*, \sigma_{-i}^*)] \geq E[u_i(\sigma_i, \sigma_{-i}^*)]$$

per ogni giocatore $i$ e ogni strategia mista alternativa $\sigma_i$.

### Teorema di Nash

Il **Teorema di Nash** afferma che ogni gioco finito (con un numero finito di giocatori e strategie) ha almeno un equilibrio di Nash in strategie miste.

## Giochi a Somma Zero

Un gioco a due giocatori è a **somma zero** se per ogni profilo di strategie $s$:

$$u_1(s) + u_2(s) = 0$$

In questi giochi, ciò che un giocatore guadagna, l'altro lo perde.

### Teorema del Minimax

Per un gioco a somma zero a due giocatori con strategie finite, il **Teorema del Minimax** afferma che:

$$\max_{\sigma_1} \min_{\sigma_2} E[u_1(\sigma_1, \sigma_2)] = \min_{\sigma_2} \max_{\sigma_1} E[u_1(\sigma_1, \sigma_2)]$$

Questo valore è chiamato **valore del gioco**. Il teorema implica che esiste una strategia ottimale per ciascun giocatore, e che queste strategie formano un equilibrio di Nash.

## Giochi Ripetuti

Un **gioco ripetuto** consiste nella ripetizione di un gioco base (stage game) per un numero finito o infinito di volte.

### Fattore di Sconto

Nei giochi ripetuti infinitamente, i payoff futuri sono spesso scontati da un fattore $\delta \in (0, 1)$. Il payoff totale per il giocatore $i$ è:

$$U_i = \sum_{t=0}^{\infty} \delta^t u_i(s^t)$$

dove $s^t$ è il profilo di strategie al tempo $t$.

### Folk Theorem

Il **Folk Theorem** afferma che in un gioco ripetuto infinitamente con fattore di sconto sufficientemente alto, qualsiasi profilo di payoff che è individualmente razionale (offre a ciascun giocatore almeno il suo valore minimax) e fattibile può essere sostenuto come un equilibrio di Nash.

Questo teorema spiega perché la cooperazione può emergere in giochi ripetuti come il Dilemma del Prigioniero, anche se la defezione è la strategia dominante nel gioco a singolo stadio.

## Giochi Bayesiani

I **giochi bayesiani** modellano situazioni con informazione incompleta, dove i giocatori hanno informazioni private (tipi).

Formalmente, un gioco bayesiano è una tupla $(N, A, \Theta, p, u)$ dove:
- $N$ è l'insieme dei giocatori
- $A = A_1 \times A_2 \times \ldots \times A_n$ è lo spazio delle azioni
- $\Theta = \Theta_1 \times \Theta_2 \times \ldots \times \Theta_n$ è lo spazio dei tipi
- $p$ è una distribuzione di probabilità su $\Theta$
- $u = (u_1, u_2, \ldots, u_n)$ dove $u_i: A \times \Theta \rightarrow \mathbb{R}$ è la funzione di payoff

Una strategia per il giocatore $i$ è una funzione $s_i: \Theta_i \rightarrow A_i$ che specifica un'azione per ogni possibile tipo.

### Equilibrio Bayesiano di Nash

Un profilo di strategie $(s_1^*, s_2^*, \ldots, s_n^*)$ è un **equilibrio bayesiano di Nash** se per ogni giocatore $i$, ogni tipo $\theta_i \in \Theta_i$ e ogni azione alternativa $a_i \in A_i$:

$$E[u_i(s_i^*(\theta_i), s_{-i}^*(\theta_{-i}), \theta) | \theta_i] \geq E[u_i(a_i, s_{-i}^*(\theta_{-i}), \theta) | \theta_i]$$

dove l'aspettativa è calcolata rispetto alla distribuzione condizionale di $\theta_{-i}$ dato $\theta_i$.

## Teoria dei Giochi Evolutiva

La **teoria dei giochi evolutiva** studia come le strategie si diffondono in una popolazione attraverso processi di selezione naturale.

### Strategia Evolutivamente Stabile

Una strategia $s^*$ è **evolutivamente stabile** se, per ogni strategia mutante $s \neq s^*$, esiste una soglia $\bar{\epsilon} > 0$ tale che per ogni $\epsilon \in (0, \bar{\epsilon})$:

$$u(s^*, (1-\epsilon)s^* + \epsilon s) > u(s, (1-\epsilon)s^* + \epsilon s)$$

dove $(1-\epsilon)s^* + \epsilon s$ rappresenta una popolazione in cui una frazione $\epsilon$ gioca la strategia mutante $s$.

In altre parole, una strategia evolutivamente stabile non può essere invasa da una piccola popolazione di mutanti.

## Applicazioni Matematiche

### Teoria delle Aste

La teoria dei giochi fornisce strumenti matematici per analizzare diversi tipi di aste:
- Asta inglese (a offerte crescenti)
- Asta olandese (a offerte decrescenti)
- Asta in busta chiusa al primo prezzo
- Asta in busta chiusa al secondo prezzo (Vickrey)

Il **Teorema di Equivalenza dei Ricavi** afferma che, sotto certe condizioni, tutti questi formati di asta generano lo stesso ricavo atteso per il venditore.

### Design dei Meccanismi

Il **design dei meccanismi** studia come progettare giochi che inducano i partecipanti a rivelare onestamente le loro informazioni private e a comportarsi in modo desiderato.

Un meccanismo è **incentive-compatible** se dire la verità è una strategia dominante per tutti i partecipanti.

Il **Teorema di Rivelazione** afferma che qualsiasi risultato di un meccanismo può essere ottenuto attraverso un meccanismo diretto incentive-compatible.

### Teoria della Contrattazione

La **teoria della contrattazione** analizza matematicamente come le parti possono raggiungere accordi in situazioni di conflitto e cooperazione.

La **soluzione di Nash alla contrattazione** massimizza il prodotto dei guadagni di utilità rispetto al punto di disaccordo:

$$\max_{x \in X} (u_1(x) - d_1) \cdot (u_2(x) - d_2)$$

dove $X$ è l'insieme dei possibili accordi e $(d_1, d_2)$ è il punto di disaccordo.
