# Concetti Fondamentali della Teoria dei Giochi

## Introduzione alla Teoria dei Giochi

La teoria dei giochi è una disciplina matematica che studia le interazioni strategiche tra agenti razionali. Un "gioco" in questo contesto è una situazione in cui più individui (giocatori) prendono decisioni che influenzano reciprocamente i loro risultati. La teoria dei giochi fornisce strumenti per analizzare come le persone prendono decisioni in situazioni di conflitto, cooperazione o competizione.

## Elementi Fondamentali di un Gioco

### Giocatori
I partecipanti che prendono decisioni. Possono essere individui, aziende, nazioni o qualsiasi entità in grado di fare scelte strategiche.

### Strategie
Le possibili azioni che un giocatore può intraprendere. Una strategia può essere semplice (una singola azione) o complessa (un piano d'azione completo che specifica cosa fare in ogni possibile situazione).

### Payoff
I risultati o le utilità che i giocatori ricevono in base alle strategie scelte da tutti i partecipanti. Solitamente rappresentati come numeri in una matrice dei payoff.

### Informazione
Ciò che i giocatori sanno al momento di prendere le loro decisioni. Un gioco può avere informazione completa (tutti conoscono le regole, i payoff e le preferenze degli altri) o incompleta.

## Tipi di Giochi

### Giochi Cooperativi vs Non Cooperativi
- **Giochi Cooperativi**: I giocatori possono formare accordi vincolanti.
- **Giochi Non Cooperativi**: I giocatori non possono formare accordi vincolanti o comunicare prima di prendere decisioni.

### Giochi a Somma Zero vs Somma Non Zero
- **Giochi a Somma Zero**: Il guadagno di un giocatore corrisponde esattamente alla perdita dell'altro (es. scacchi, poker).
- **Giochi a Somma Non Zero**: Tutti i giocatori possono guadagnare o perdere insieme (es. Dilemma del Prigioniero).

### Giochi Simultanei vs Sequenziali
- **Giochi Simultanei**: I giocatori scelgono le loro strategie contemporaneamente (es. Sasso, Carta, Forbice).
- **Giochi Sequenziali**: I giocatori scelgono le loro strategie in ordine, conoscendo le mosse precedenti (es. scacchi).

### Giochi ad Informazione Completa vs Incompleta
- **Informazione Completa**: Tutti i giocatori conoscono le regole del gioco e i payoff di tutti.
- **Informazione Incompleta**: Alcuni giocatori hanno informazioni private (es. poker, dove non si conoscono le carte degli avversari).

### Giochi ad Informazione Perfetta vs Imperfetta
- **Informazione Perfetta**: In ogni momento, tutti i giocatori conoscono tutte le mosse precedenti (es. scacchi).
- **Informazione Imperfetta**: Alcune mosse precedenti potrebbero essere nascoste (es. poker).

## Concetti di Soluzione

### Strategia Dominante
Una strategia che offre un risultato migliore rispetto a qualsiasi altra strategia, indipendentemente dalle scelte degli altri giocatori. Se esiste una strategia dominante, un giocatore razionale dovrebbe sempre sceglierla.

### Equilibrio di Nash
Una situazione in cui nessun giocatore può migliorare il proprio risultato cambiando solo la propria strategia, dato che gli altri mantengono le loro. L'equilibrio di Nash rappresenta una situazione di stabilità strategica.

### Ottimo di Pareto
Una situazione in cui non è possibile migliorare il risultato di un giocatore senza peggiorare quello di almeno un altro. Un risultato Pareto-efficiente è collettivamente ottimale.

### Minimax e Maximin
- **Minimax**: Strategia che minimizza la massima perdita possibile (usata in giochi a somma zero).
- **Maximin**: Strategia che massimizza il minimo guadagno possibile.

## Esempi Classici di Giochi

### Dilemma del Prigioniero
Due sospetti devono decidere se confessare o rimanere in silenzio. La scelta individualmente razionale (confessare) porta a un risultato collettivamente sub-ottimale.

**Matrice dei Payoff:**
```
            Prigioniero B
            Silenzio    Confessa
Prigioniero A
Silenzio     (-1,-1)    (-10,0)
Confessa     (0,-10)    (-5,-5)
```

### Hawk-Dove (Falco-Colomba)
Modella il conflitto tra comportamenti aggressivi e pacifici. Se entrambi i giocatori sono aggressivi, entrambi subiscono gravi danni.

**Matrice dei Payoff:**
```
        Giocatore B
        Falco       Colomba
Giocatore A
Falco   (-2,-2)     (4,0)
Colomba (0,4)       (2,2)
```

### Stag Hunt (Caccia al Cervo)
Modella il conflitto tra cooperazione e sicurezza. La cooperazione offre il risultato migliore, ma solo se tutti cooperano.

**Matrice dei Payoff:**
```
        Giocatore B
        Cervo       Lepre
Giocatore A
Cervo   (4,4)       (0,3)
Lepre   (3,0)       (2,2)
```

### Battle of the Sexes (Battaglia dei Sessi)
Modella situazioni in cui i giocatori preferiscono coordinarsi, ma hanno preferenze diverse su come farlo.

**Matrice dei Payoff:**
```
        Giocatore B
        Opera       Calcio
Giocatore A
Opera   (3,2)       (0,0)
Calcio  (0,0)       (2,3)
```

## Strategie in Giochi Ripetuti

### Tit for Tat
Coopera al primo turno, poi replica la mossa dell'avversario nel turno precedente. Questa strategia ha dimostrato grande efficacia nei tornei di Dilemma del Prigioniero iterato.

### Grim Trigger
Coopera finché l'avversario coopera, ma passa permanentemente alla defezione dopo il primo tradimento dell'avversario.

### Pavlov (Win-Stay, Lose-Shift)
Mantiene la stessa mossa se ha vinto, cambia se ha perso. Questa strategia può adattarsi all'ambiente e imparare dai propri errori.

## Applicazioni della Teoria dei Giochi

### Economia
Analisi di mercati, aste, contrattazione, concorrenza oligopolistica e comportamento strategico delle imprese.

### Scienze Politiche
Studio di votazioni, formazione di coalizioni, conflitti internazionali e negoziati.

### Biologia
Evoluzione del comportamento animale, selezione naturale e strategie di sopravvivenza.

### Informatica
Algoritmi distribuiti, sicurezza informatica, intelligenza artificiale e apprendimento automatico.

### Etica e Filosofia
Analisi di dilemmi morali, cooperazione sociale e fondamenti della giustizia.
