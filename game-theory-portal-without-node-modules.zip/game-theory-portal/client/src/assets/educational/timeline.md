# Timeline della Storia della Teoria dei Giochi

## Origini e Fondamenti (1920-1940)

### 1921 - Émile Borel
Émile Borel, matematico francese, pubblica diversi articoli sulla teoria dei giochi strategici. È uno dei primi a formalizzare l'idea di strategie miste e a studiare giochi a somma zero con due giocatori.

### 1928 - John von Neumann
John von Neumann pubblica "Zur Theorie der Gesellschaftsspiele" (Sulla Teoria dei Giochi di Società), dove dimostra il teorema del minimax, fondamentale per i giochi a somma zero con due giocatori. Questo articolo è considerato l'inizio formale della teoria dei giochi moderna.

### 1944 - "Theory of Games and Economic Behavior"
John von Neumann e Oskar Morgenstern pubblicano "Theory of Games and Economic Behavior", il primo trattato completo sulla teoria dei giochi. Il libro introduce concetti fondamentali come la forma estensiva e la forma normale dei giochi, e applica la teoria dei giochi all'economia.

## L'Era di Nash e l'Equilibrio (1950-1960)

### 1950-1953 - John Nash
John Nash pubblica una serie di articoli fondamentali che introducono il concetto di "equilibrio di Nash" per giochi non cooperativi. Dimostra che ogni gioco finito ha almeno un punto di equilibrio (in strategie pure o miste). Questo concetto rivoluziona la teoria dei giochi, estendendola oltre i giochi a somma zero.

### 1950 - Il Dilemma del Prigioniero
Merrill Flood e Melvin Dresher della RAND Corporation sviluppano il Dilemma del Prigioniero, successivamente formalizzato e nominato da Albert W. Tucker. Questo gioco diventa uno dei più studiati nella teoria dei giochi per la sua capacità di modellare il conflitto tra interesse individuale e collettivo.

### 1957 - Giochi Ripetuti
Robert Aumann inizia a studiare i giochi ripetuti, dimostrando come la ripetizione possa portare a risultati cooperativi anche in giochi non cooperativi come il Dilemma del Prigioniero.

## Applicazioni ed Espansioni (1960-1980)

### 1960-1970 - Teoria dei Giochi Evolutiva
John Maynard Smith e George R. Price applicano la teoria dei giochi alla biologia evolutiva, sviluppando il concetto di "strategia evolutivamente stabile" (ESS). Introducono giochi come Hawk-Dove per modellare i conflitti tra animali.

### 1965 - Giochi Cooperativi
Lloyd Shapley e Martin Shubik sviluppano ulteriormente la teoria dei giochi cooperativi, introducendo concetti come il valore di Shapley e applicandoli a problemi economici.

### 1967-1968 - Giochi Bayesiani
John Harsanyi sviluppa la teoria dei giochi con informazione incompleta (giochi bayesiani), dove i giocatori hanno informazioni private sulle proprie preferenze o sulle regole del gioco.

### 1972 - "L'Evoluzione della Cooperazione"
Robert Axelrod organizza tornei computerizzati per il Dilemma del Prigioniero iterato, dove la strategia Tit for Tat di Anatol Rapoport emerge come vincitrice. Questi risultati vengono poi pubblicati nel libro "L'Evoluzione della Cooperazione" (1984).

## Riconoscimenti e Applicazioni Moderne (1980-2000)

### 1994 - Premio Nobel per l'Economia
John Nash, John Harsanyi e Reinhard Selten ricevono il Premio Nobel per l'Economia per il loro lavoro pionieristico sulla teoria dei giochi non cooperativi.

### 1996-2007 - Aste e Design dei Meccanismi
La teoria dei giochi viene applicata al design delle aste e dei meccanismi, con contributi significativi di Roger Myerson, Eric Maskin e Leonid Hurwicz, che ricevono il Premio Nobel nel 2007.

### 2005 - Premio Nobel per l'Economia
Robert Aumann e Thomas Schelling ricevono il Premio Nobel per l'Economia per aver migliorato la comprensione del conflitto e della cooperazione attraverso l'analisi della teoria dei giochi.

## Era Contemporanea (2000-Presente)

### 2000-2010 - Teoria dei Giochi Algoritmica
La teoria dei giochi si fonde con l'informatica teorica, dando origine alla teoria dei giochi algoritmica, che studia problemi computazionali in contesti strategici.

### 2012 - Premio Nobel per l'Economia
Alvin E. Roth e Lloyd S. Shapley ricevono il Premio Nobel per l'Economia per la teoria delle allocazioni stabili e la pratica del design di mercato.

### 2014-Presente - Intelligenza Artificiale e Apprendimento Automatico
La teoria dei giochi diventa fondamentale nello sviluppo di algoritmi di intelligenza artificiale, con applicazioni in sistemi multi-agente, apprendimento per rinforzo e teoria delle decisioni.

### 2020-Presente - Applicazioni Interdisciplinari
La teoria dei giochi continua a espandersi in nuovi campi, dalla psicologia alla scienza politica, dalle reti sociali alla gestione delle risorse naturali, dimostrando la sua versatilità come strumento per comprendere le interazioni strategiche in diversi contesti.
