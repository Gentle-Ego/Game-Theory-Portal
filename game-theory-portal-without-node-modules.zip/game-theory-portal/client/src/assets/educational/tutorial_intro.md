# Tutorial: Introduzione alla Teoria dei Giochi

## Obiettivo del Tutorial
Questo tutorial ti guiderà attraverso i concetti fondamentali della teoria dei giochi, partendo dalle basi fino ad arrivare all'applicazione pratica. Alla fine, sarai in grado di analizzare situazioni strategiche semplici utilizzando gli strumenti della teoria dei giochi.

## Prerequisiti
- Nessuna conoscenza pregressa di teoria dei giochi
- Comprensione base della matematica (addizione, sottrazione, concetto di probabilità)
- Curiosità e voglia di imparare!

## Passo 1: Cos'è la Teoria dei Giochi?

La teoria dei giochi è una disciplina matematica che studia le interazioni strategiche tra individui razionali (chiamati "giocatori"). Un "gioco" in questo contesto è qualsiasi situazione in cui:
1. Ci sono almeno due giocatori
2. Ogni giocatore ha diverse possibili azioni (o "strategie")
3. Il risultato per ciascun giocatore dipende non solo dalle proprie scelte, ma anche dalle scelte degli altri

**Esercizio 1.1**: Identifica tre situazioni della vita quotidiana che potrebbero essere analizzate come "giochi" secondo questa definizione.

## Passo 2: Rappresentazione dei Giochi

I giochi possono essere rappresentati in diversi modi. Il più semplice è la **forma normale** o **matrice dei payoff**, che mostra i giocatori, le loro strategie e i risultati (payoff) per ogni combinazione di strategie.

Consideriamo un semplice gioco a due giocatori, dove ciascuno ha due possibili strategie: A e B.

```
                Giocatore 2
                A        B
Giocatore 1
A         (3,3)    (1,4)
B         (4,1)    (2,2)
```

In questa matrice:
- Il primo numero in ogni cella rappresenta il payoff del Giocatore 1
- Il secondo numero rappresenta il payoff del Giocatore 2
- Numeri più alti sono preferibili (rappresentano maggiore utilità)

**Esercizio 2.1**: Interpreta la matrice. Quale combinazione di strategie dà il miglior risultato per il Giocatore 1? E per il Giocatore 2? Esiste una combinazione che sia la migliore per entrambi?

## Passo 3: Strategie Dominanti

Una **strategia dominante** è una strategia che è sempre migliore per un giocatore, indipendentemente da ciò che fanno gli altri giocatori.

Per identificare una strategia dominante:
1. Confronta i payoff di una strategia con quelli di un'altra, mantenendo fisse le strategie degli altri giocatori
2. Se una strategia offre sempre payoff maggiori o uguali, con almeno un caso di payoff strettamente maggiore, allora è dominante

**Esempio**: Nel seguente gioco, il Giocatore 1 ha una strategia dominante?

```
                Giocatore 2
                A        B
Giocatore 1
A         (5,1)    (3,0)
B         (2,3)    (1,2)
```

Analizziamo:
- Se il Giocatore 2 sceglie A: il Giocatore 1 ottiene 5 con A e 2 con B → A è meglio
- Se il Giocatore 2 sceglie B: il Giocatore 1 ottiene 3 con A e 1 con B → A è meglio

Quindi A è una strategia dominante per il Giocatore 1.

**Esercizio 3.1**: Nel gioco sopra, il Giocatore 2 ha una strategia dominante? Se sì, quale?

## Passo 4: Equilibrio di Nash

L'**equilibrio di Nash** è una combinazione di strategie in cui nessun giocatore può migliorare il proprio risultato cambiando solo la propria strategia, dato che gli altri mantengono le loro.

Per trovare un equilibrio di Nash:
1. Per ogni giocatore, identifica la "miglior risposta" a ogni possibile strategia degli altri
2. Se una combinazione di strategie è la miglior risposta per tutti i giocatori, allora è un equilibrio di Nash

**Esempio**: Troviamo l'equilibrio di Nash nel seguente gioco:

```
                Giocatore 2
                A        B
Giocatore 1
A         (2,2)    (0,0)
B         (0,0)    (1,1)
```

Analizziamo:
- Se il Giocatore 2 sceglie A: la miglior risposta del Giocatore 1 è A (2 > 0)
- Se il Giocatore 2 sceglie B: la miglior risposta del Giocatore 1 è B (1 > 0)
- Se il Giocatore 1 sceglie A: la miglior risposta del Giocatore 2 è A (2 > 0)
- Se il Giocatore 1 sceglie B: la miglior risposta del Giocatore 2 è B (1 > 0)

Quindi ci sono due equilibri di Nash: (A,A) e (B,B).

**Esercizio 4.1**: Trova l'equilibrio di Nash nel seguente gioco:

```
                Giocatore 2
                A        B
Giocatore 1
A         (3,2)    (1,1)
B         (0,0)    (2,3)
```

## Passo 5: Il Dilemma del Prigioniero

Il **Dilemma del Prigioniero** è uno dei giochi più famosi e studiati. Due sospetti vengono interrogati separatamente e devono decidere se confessare o rimanere in silenzio.

```
                Prigioniero B
                Silenzio   Confessa
Prigioniero A
Silenzio     (-1,-1)    (-10,0)
Confessa     (0,-10)    (-5,-5)
```

Dove i numeri rappresentano gli anni di prigione (negativi perché sono una punizione).

**Analisi**:
1. Ogni prigioniero ha una strategia dominante: confessare
2. L'equilibrio di Nash è (Confessa, Confessa)
3. Paradossalmente, se entrambi rimanessero in silenzio, otterrebbero un risultato migliore

Questo gioco illustra il conflitto tra razionalità individuale e ottimalità collettiva.

**Esercizio 5.1**: Immagina che il gioco venga ripetuto più volte. Come potrebbe cambiare la strategia ottimale?

## Passo 6: Strategie Miste

Finora abbiamo considerato solo **strategie pure** (scegliere una specifica azione). Le **strategie miste** implicano l'uso di probabilità.

Una strategia mista assegna una probabilità a ciascuna strategia pura. Ad esempio, "giocare A con probabilità 0.7 e B con probabilità 0.3".

Le strategie miste sono utili quando:
1. Non esiste un equilibrio di Nash in strategie pure
2. Si vuole essere imprevedibili (come nel gioco Sasso-Carta-Forbice)

**Esempio**: Nel gioco Sasso-Carta-Forbice, la strategia mista ottimale è giocare ciascuna opzione con probabilità 1/3.

**Esercizio 6.1**: Perché essere prevedibili nel gioco Sasso-Carta-Forbice sarebbe svantaggioso?

## Passo 7: Applicazione Pratica - Analisi di un Gioco Reale

Analizziamo una situazione di negoziazione salariale tra un'azienda e un candidato.

```
                Azienda
                Offerta Alta   Offerta Bassa
Candidato
Accetta      (3,2)         (1,4)
Rifiuta      (0,0)         (0,0)
```

Dove i numeri rappresentano l'utilità per ciascuna parte.

**Analisi**:
1. Se il candidato accetta sempre, l'azienda offrirà sempre l'offerta bassa
2. Se il candidato rifiuta le offerte basse, l'azienda potrebbe essere incentivata a fare offerte alte
3. L'equilibrio dipende dalla credibilità della minaccia di rifiuto

**Esercizio 7.1**: Come cambierebbe l'analisi se il candidato avesse altre offerte di lavoro?

## Conclusione

Congratulazioni! Hai completato il tutorial introduttivo sulla teoria dei giochi. Ora dovresti essere in grado di:
1. Identificare situazioni che possono essere analizzate come giochi
2. Rappresentare giochi in forma normale
3. Identificare strategie dominanti
4. Trovare equilibri di Nash
5. Comprendere il Dilemma del Prigioniero e le sue implicazioni
6. Capire il concetto di strategie miste
7. Applicare questi concetti a situazioni reali

## Prossimi Passi

Per approfondire la tua conoscenza della teoria dei giochi:
1. Esplora i giochi sequenziali e la forma estensiva
2. Studia i giochi ripetuti e le strategie evolutivamente stabili
3. Approfondisci i giochi a informazione incompleta
4. Applica la teoria dei giochi a problemi specifici del tuo campo di interesse

Buona fortuna con le tue future esplorazioni nella teoria dei giochi!
