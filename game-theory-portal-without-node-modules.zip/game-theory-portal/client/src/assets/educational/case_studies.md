# Casi di Studio: Teoria dei Giochi nel Mondo Reale

## Economia e Business

### 1. Guerra dei Prezzi tra Compagnie Aeree

**Scenario**: Negli anni '90, le principali compagnie aeree americane si trovarono in una situazione simile al Dilemma del Prigioniero quando dovevano decidere se mantenere prezzi alti o abbassarli per guadagnare quote di mercato.

**Analisi**: Ogni compagnia aveva un incentivo a tagliare i prezzi per attirare più clienti. Tuttavia, quando tutte le compagnie tagliavano i prezzi, il risultato era una riduzione dei profitti per l'intero settore. Questo è un classico esempio di come le decisioni individualmente razionali possano portare a risultati collettivamente sub-ottimali.

**Risultato**: Le compagnie aeree svilupparono sistemi di segnalazione dei prezzi e programmi di fidelizzazione per stabilizzare i prezzi e ridurre la competizione distruttiva.

### 2. Cartello OPEC

**Scenario**: L'Organizzazione dei Paesi Esportatori di Petrolio (OPEC) rappresenta un esempio di gioco cooperativo in cui i membri cercano di coordinare la produzione di petrolio per mantenere i prezzi alti.

**Analisi**: Ogni membro dell'OPEC ha un incentivo a produrre più petrolio di quanto concordato (defezione), poiché può vendere più barili mantenendo il prezzo alto se gli altri membri rispettano le quote. Tuttavia, se tutti i membri defezionano, il prezzo crolla.

**Risultato**: L'OPEC ha avuto periodi di successo e fallimento. La sua efficacia dipende dalla capacità di monitorare la produzione dei membri e imporre sanzioni ai trasgressori, nonché da fattori esterni come la domanda globale e la produzione di paesi non-OPEC.

### 3. Aste dello Spettro Radio

**Scenario**: Nel 1994, la Federal Communications Commission (FCC) degli Stati Uniti iniziò a utilizzare aste simultanee a più round per allocare lo spettro radio per le telecomunicazioni.

**Analisi**: Il design dell'asta fu sviluppato utilizzando la teoria dei giochi per incentivare le aziende a rivelare il vero valore che attribuivano alle licenze. Le aste simultanee a più round permettevano ai partecipanti di osservare le offerte degli altri e adattare le proprie strategie.

**Risultato**: Questo approccio ha generato miliardi di dollari di entrate per il governo e ha portato a un'allocazione efficiente dello spettro. È considerato un grande successo dell'applicazione pratica della teoria dei giochi e del design dei meccanismi.

## Politica e Relazioni Internazionali

### 4. Crisi dei Missili di Cuba

**Scenario**: Nel 1962, Stati Uniti e Unione Sovietica si trovarono in una pericolosa situazione di confronto quando l'URSS installò missili nucleari a Cuba.

**Analisi**: Questa crisi può essere modellata come un gioco del "Chicken" (o Hawk-Dove), dove entrambe le parti devono decidere se mantenere una posizione aggressiva o cedere. Se entrambe mantengono la posizione aggressiva, il risultato è catastrofico (guerra nucleare).

**Risultato**: La crisi si risolse con un compromesso: l'URSS rimosse i missili da Cuba, mentre gli USA si impegnarono a non invadere Cuba e rimossero segretamente alcuni missili dalla Turchia. Questo equilibrio evitò il peggior risultato possibile e dimostrò l'importanza della comunicazione e dei segnali credibili nelle crisi internazionali.

### 5. Negoziati sul Cambiamento Climatico

**Scenario**: Gli accordi internazionali sul clima, come il Protocollo di Kyoto e l'Accordo di Parigi, rappresentano tentativi di risolvere un problema di azione collettiva globale.

**Analisi**: La riduzione delle emissioni di gas serra può essere modellata come un gioco dei beni pubblici. Ogni paese ha un incentivo a non ridurre le proprie emissioni (free-riding) mentre beneficia delle riduzioni degli altri. Tuttavia, se tutti i paesi seguono questa logica, il risultato è catastrofico per tutti.

**Risultato**: Gli accordi sul clima cercano di superare questo dilemma attraverso impegni vincolanti, monitoraggio, incentivi economici e pressione internazionale. L'efficacia di questi accordi dipende dalla capacità di allineare gli interessi individuali dei paesi con l'interesse collettivo globale.

## Biologia ed Evoluzione

### 6. Comportamento Altruistico negli Animali

**Scenario**: In natura, si osservano comportamenti apparentemente altruistici, come quando gli animali emettono richiami di allarme che avvertono gli altri del pericolo ma attirano l'attenzione dei predatori su di sé.

**Analisi**: La teoria dei giochi evolutiva spiega questi comportamenti attraverso concetti come la selezione di parentela e l'altruismo reciproco. Gli individui che aiutano i parenti stanno indirettamente promuovendo la sopravvivenza dei propri geni.

**Risultato**: Studi sul campo hanno confermato che molti comportamenti cooperativi negli animali seguono le previsioni della teoria dei giochi evolutiva, dimostrando come la cooperazione possa emergere attraverso meccanismi evolutivi anche in assenza di ragionamento strategico consapevole.

### 7. Strategie di Accoppiamento

**Scenario**: Le strategie di accoppiamento negli animali possono essere analizzate utilizzando la teoria dei giochi.

**Analisi**: In molte specie, i maschi devono decidere quanto investire nel corteggiamento e nella cura della prole, mentre le femmine devono scegliere tra partner potenziali. Queste decisioni possono essere modellate come giochi strategici.

**Risultato**: La teoria dei giochi ha aiutato a spiegare fenomeni come il dimorfismo sessuale, i rituali di corteggiamento elaborati e i diversi sistemi di accoppiamento (monogamia, poligamia, ecc.) osservati in natura.

## Tecnologia e Reti

### 8. Sicurezza Informatica e Attacchi DDoS

**Scenario**: Le organizzazioni devono decidere quanto investire in sicurezza informatica per proteggersi da attacchi come quelli Distributed Denial of Service (DDoS).

**Analisi**: Questo può essere modellato come un gioco tra difensori e attaccanti, dove i difensori devono allocare risorse limitate tra diverse misure di sicurezza, mentre gli attaccanti cercano di identificare e sfruttare i punti deboli.

**Risultato**: L'applicazione della teoria dei giochi alla sicurezza informatica ha portato allo sviluppo di strategie di difesa più efficaci, come l'uso di honeypots, la diversificazione dei sistemi e l'adozione di approcci probabilistici alla sicurezza.

### 9. Condivisione di File Peer-to-Peer

**Scenario**: Nelle reti di condivisione file peer-to-peer come BitTorrent, gli utenti devono decidere se condividere i propri file (upload) o solo scaricare (download).

**Analisi**: Questo rappresenta un classico problema di free-riding: ogni utente ha un incentivo a scaricare senza condividere, ma se tutti seguono questa strategia, il sistema collassa.

**Risultato**: BitTorrent ha implementato un meccanismo di "tit-for-tat" che favorisce gli utenti che condividono più contenuti, dimostrando come il design del protocollo possa incentivare la cooperazione anche in un ambiente anonimo e decentralizzato.

## Vita Quotidiana

### 10. Traffico e Congestione Stradale

**Scenario**: Gli automobilisti devono scegliere quotidianamente tra percorsi alternativi per raggiungere la loro destinazione.

**Analisi**: Questa situazione può essere modellata come un gioco in cui ogni automobilista cerca di minimizzare il proprio tempo di viaggio. Il paradosso di Braess dimostra che, in alcune reti stradali, aggiungere una nuova strada può aumentare la congestione complessiva perché gli automobilisti che agiscono nel proprio interesse creano un equilibrio sub-ottimale.

**Risultato**: La comprensione di questi paradossi ha influenzato la pianificazione urbana e ha portato a soluzioni come i pedaggi di congestione, che utilizzano incentivi economici per allineare gli interessi individuali con quelli collettivi.

### 11. Dinamiche di Gruppo e Coordinamento Sociale

**Scenario**: In situazioni sociali, le persone devono spesso coordinarsi su convenzioni come l'orario di inizio di un evento o il luogo di incontro.

**Analisi**: Questi scenari possono essere modellati come giochi di coordinamento, dove i giocatori beneficiano dal fare la stessa scelta, indipendentemente da quale sia questa scelta.

**Risultato**: Le convenzioni sociali emergono come soluzioni a questi giochi di coordinamento. La teoria dei giochi aiuta a spiegare perché alcune convenzioni persistono anche quando non sono ottimali e come nuove convenzioni possono emergere e diffondersi in una popolazione.

## Conclusioni

Questi casi di studio dimostrano la versatilità della teoria dei giochi come strumento per analizzare e comprendere una vasta gamma di fenomeni del mondo reale. Dall'economia alla biologia, dalla politica alla tecnologia, i principi della teoria dei giochi offrono preziose intuizioni sui meccanismi che governano le interazioni strategiche tra agenti razionali.

La teoria dei giochi non solo aiuta a spiegare comportamenti osservati, ma fornisce anche indicazioni su come progettare istituzioni, meccanismi e incentivi per promuovere risultati socialmente desiderabili. Comprendere la logica strategica sottostante alle interazioni umane è essenziale per affrontare molte delle sfide complesse che la società moderna deve affrontare.
