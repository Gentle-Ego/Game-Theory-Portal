// Test di funzionalità per il Game Theory Portal
// Questo script esegue test automatizzati sui componenti principali del sito

import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import { AppProvider } from '../utils/AppContext';
import Home from '../pages/Home';
import Login from '../pages/Login';
import Register from '../pages/Register';
import GameArena from '../pages/GameArena';
import Educational from '../pages/Educational';

// Mock delle funzioni di Firebase
jest.mock('../utils/firebase', () => ({
  loginWithEmailAndPassword: jest.fn(),
  registerWithEmailAndPassword: jest.fn(),
  loginWithGoogle: jest.fn(),
  loginWithGithub: jest.fn(),
  getCurrentUser: jest.fn(),
  logout: jest.fn()
}));

// Test della Home Page
describe('Home Page', () => {
  test('Rendering dei componenti principali', () => {
    render(
      <BrowserRouter>
        <AppProvider>
          <Home />
        </AppProvider>
      </BrowserRouter>
    );
    
    // Verifica che gli elementi principali siano presenti
    expect(screen.getByText(/Game Theory Portal/i)).toBeInTheDocument();
    expect(screen.getByText(/Teoria dei Giochi/i)).toBeInTheDocument();
    expect(screen.getByText(/Inizia a giocare/i)).toBeInTheDocument();
  });
  
  test('Navigazione ai giochi', () => {
    render(
      <BrowserRouter>
        <AppProvider>
          <Home />
        </AppProvider>
      </BrowserRouter>
    );
    
    // Trova e clicca sul pulsante per iniziare a giocare
    const playButton = screen.getByText(/Inizia a giocare/i);
    fireEvent.click(playButton);
    
    // Verifica che la navigazione sia avvenuta (mock)
    // In un test reale, verificheremmo il cambio di URL
  });
});

// Test della pagina di Login
describe('Login Page', () => {
  test('Rendering del form di login', () => {
    render(
      <BrowserRouter>
        <AppProvider>
          <Login />
        </AppProvider>
      </BrowserRouter>
    );
    
    // Verifica che gli elementi del form siano presenti
    expect(screen.getByLabelText(/Email/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/Password/i)).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /Accedi/i })).toBeInTheDocument();
  });
  
  test('Invio del form di login', async () => {
    const mockLoginFn = require('../utils/firebase').loginWithEmailAndPassword;
    mockLoginFn.mockResolvedValueOnce({ success: true, user: { email: 'test@example.com' } });
    
    render(
      <BrowserRouter>
        <AppProvider>
          <Login />
        </AppProvider>
      </BrowserRouter>
    );
    
    // Compila il form
    fireEvent.change(screen.getByLabelText(/Email/i), {
      target: { value: 'test@example.com' }
    });
    fireEvent.change(screen.getByLabelText(/Password/i), {
      target: { value: 'password123' }
    });
    
    // Invia il form
    fireEvent.click(screen.getByRole('button', { name: /Accedi/i }));
    
    // Verifica che la funzione di login sia stata chiamata con i parametri corretti
    await waitFor(() => {
      expect(mockLoginFn).toHaveBeenCalledWith('test@example.com', 'password123');
    });
  });
});

// Test della pagina di Registrazione
describe('Register Page', () => {
  test('Rendering del form di registrazione', () => {
    render(
      <BrowserRouter>
        <AppProvider>
          <Register />
        </AppProvider>
      </BrowserRouter>
    );
    
    // Verifica che gli elementi del form siano presenti
    expect(screen.getByLabelText(/Nome utente/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/Email/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/^Password/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/Conferma Password/i)).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /Registrati/i })).toBeInTheDocument();
  });
  
  test('Validazione delle password', async () => {
    render(
      <BrowserRouter>
        <AppProvider>
          <Register />
        </AppProvider>
      </BrowserRouter>
    );
    
    // Compila il form con password diverse
    fireEvent.change(screen.getByLabelText(/Nome utente/i), {
      target: { value: 'testuser' }
    });
    fireEvent.change(screen.getByLabelText(/Email/i), {
      target: { value: 'test@example.com' }
    });
    fireEvent.change(screen.getByLabelText(/^Password/i), {
      target: { value: 'password123' }
    });
    fireEvent.change(screen.getByLabelText(/Conferma Password/i), {
      target: { value: 'password456' }
    });
    
    // Invia il form
    fireEvent.click(screen.getByRole('button', { name: /Registrati/i }));
    
    // Verifica che appaia un messaggio di errore
    await waitFor(() => {
      expect(screen.getByText(/Le password non corrispondono/i)).toBeInTheDocument();
    });
  });
});

// Test della Game Arena
describe('Game Arena', () => {
  test('Rendering dei giochi disponibili', () => {
    render(
      <BrowserRouter>
        <AppProvider>
          <GameArena />
        </AppProvider>
      </BrowserRouter>
    );
    
    // Verifica che i giochi principali siano presenti
    expect(screen.getByText(/Dilemma del Prigioniero/i)).toBeInTheDocument();
    expect(screen.getByText(/Hawk-Dove/i)).toBeInTheDocument();
    expect(screen.getByText(/Stag Hunt/i)).toBeInTheDocument();
    expect(screen.getByText(/Public Goods/i)).toBeInTheDocument();
  });
});

// Test della sezione Educational
describe('Educational Section', () => {
  test('Rendering dei contenuti educativi', () => {
    render(
      <BrowserRouter>
        <AppProvider>
          <Educational />
        </AppProvider>
      </BrowserRouter>
    );
    
    // Verifica che le sezioni principali siano presenti
    expect(screen.getByText(/Storia della Teoria dei Giochi/i)).toBeInTheDocument();
    expect(screen.getByText(/Concetti Fondamentali/i)).toBeInTheDocument();
    expect(screen.getByText(/Basi Matematiche/i)).toBeInTheDocument();
    expect(screen.getByText(/Casi di Studio/i)).toBeInTheDocument();
  });
});

// Esporta i test per l'esecuzione
export default {
  Home,
  Login,
  Register,
  GameArena,
  Educational
};
