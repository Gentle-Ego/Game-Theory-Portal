/**
 * Implementazione del Public Goods Game
 * 
 * Questo modulo implementa il gioco Public Goods (Beni Pubblici)
 * utilizzando il motore di teoria dei giochi.
 */

class PublicGoodsGame {
  constructor(numPlayers = 4, multiplier = 2, initialEndowment = 10) {
    this.id = 'public-goods';
    this.name = 'Public Goods Game';
    this.description = 'Un gioco che esplora come gli individui contribuiscono a un bene comune.';
    this.numPlayers = numPlayers;
    this.multiplier = multiplier;
    this.initialEndowment = initialEndowment;
  }

  /**
   * Restituisce lo stato iniziale del gioco
   * @returns {object} Stato iniziale
   */
  initialState() {
    const scores = {};
    for (let i = 1; i <= this.numPlayers; i++) {
      scores[i] = 0;
    }
    
    return {
      round: 0,
      history: [],
      scores,
      endowments: Object.fromEntries(
        Array.from({ length: this.numPlayers }, (_, i) => [i + 1, this.initialEndowment])
      )
    };
  }

  /**
   * Risolve un round del gioco
   * @param {object} contributions - Contributi di ciascun giocatore, es. {1: 5, 2: 3, 3: 0, 4: 10}
   * @param {object} gameState - Stato attuale del gioco
   * @returns {object} Risultato del round
   */
  resolveRound(contributions, gameState) {
    // Verifica che i contributi siano validi
    for (const [player, contribution] of Object.entries(contributions)) {
      const playerNum = parseInt(player);
      if (contribution < 0 || contribution > gameState.endowments[playerNum]) {
        throw new Error(`Contributo non valido per il giocatore ${player}. Deve essere tra 0 e ${gameState.endowments[playerNum]}.`);
      }
    }
    
    // Calcola il totale dei contributi
    const totalContribution = Object.values(contributions).reduce((sum, val) => sum + val, 0);
    
    // Calcola il bene pubblico
    const publicGood = totalContribution * this.multiplier;
    
    // Calcola il ritorno per ciascun giocatore
    const returnPerPlayer = publicGood / this.numPlayers;
    
    // Calcola i payoff
    const payoffs = {};
    const newEndowments = {};
    
    for (let i = 1; i <= this.numPlayers; i++) {
      const contribution = contributions[i] || 0;
      const remaining = gameState.endowments[i] - contribution;
      payoffs[i] = remaining + returnPerPlayer;
      newEndowments[i] = this.initialEndowment; // Reset per il prossimo round
    }
    
    return {
      round: gameState.round + 1,
      contributions,
      totalContribution,
      publicGood,
      returnPerPlayer,
      payoffs,
      newEndowments
    };
  }

  /**
   * Aggiorna lo stato del gioco dopo un round
   * @param {object} gameState - Stato attuale del gioco
   * @param {object} roundResult - Risultato del round
   * @returns {object} Nuovo stato del gioco
   */
  updateState(gameState, roundResult) {
    const newScores = { ...gameState.scores };
    
    for (let i = 1; i <= this.numPlayers; i++) {
      newScores[i] += roundResult.payoffs[i];
    }
    
    return {
      round: roundResult.round,
      history: [...gameState.history, roundResult],
      scores: newScores,
      endowments: roundResult.newEndowments
    };
  }

  /**
   * Calcola i punteggi finali di una partita
   * @param {object[]} history - Cronologia dei round
   * @returns {object} Punteggi finali
   */
  calculateScores(history) {
    const scores = {};
    for (let i = 1; i <= this.numPlayers; i++) {
      scores[i] = 0;
    }
    
    return history.reduce((acc, round) => {
      for (let i = 1; i <= this.numPlayers; i++) {
        acc[i] += round.payoffs[i];
      }
      return acc;
    }, scores);
  }

  /**
   * Verifica se un contributo è valido
   * @param {number} contribution - Contributo da verificare
   * @param {number} endowment - Dotazione attuale del giocatore
   * @returns {boolean} True se il contributo è valido
   */
  isValidContribution(contribution, endowment) {
    return contribution >= 0 && contribution <= endowment;
  }

  /**
   * Restituisce una descrizione testuale del risultato di un round
   * @param {object} roundResult - Risultato del round
   * @returns {string} Descrizione testuale
   */
  getResultDescription(roundResult) {
    const { contributions, totalContribution, publicGood, returnPerPlayer } = roundResult;
    
    let description = `Round ${roundResult.round}:\n`;
    description += `Contributo totale: ${totalContribution} unità.\n`;
    description += `Bene pubblico generato: ${publicGood} unità (moltiplicatore: ${this.multiplier}).\n`;
    description += `Ritorno per ciascun giocatore: ${returnPerPlayer} unità.\n\n`;
    
    description += "Contributi individuali:\n";
    for (const [player, contribution] of Object.entries(contributions)) {
      const remaining = this.initialEndowment - contribution;
      const payoff = roundResult.payoffs[player];
      description += `Giocatore ${player}: ha contribuito ${contribution} unità, ha tenuto ${remaining} unità, guadagno totale: ${payoff} unità.\n`;
    }
    
    // Calcola l'efficienza sociale
    const maxPossiblePublicGood = this.initialEndowment * this.numPlayers * this.multiplier;
    const efficiency = (publicGood / maxPossiblePublicGood) * 100;
    
    description += `\nEfficienza sociale: ${efficiency.toFixed(2)}%`;
    
    return description;
  }
}

export default PublicGoodsGame;
