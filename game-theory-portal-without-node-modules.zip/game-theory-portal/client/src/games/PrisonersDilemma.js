/**
 * Implementazione del Dilemma del Prigioniero
 * 
 * Questo modulo implementa il classico gioco del Dilemma del Prigioniero
 * utilizzando il motore di teoria dei giochi.
 */

class PrisonersDilemma {
  constructor() {
    this.id = 'prisoners-dilemma';
    this.name = 'Dilemma del Prigioniero';
    this.description = 'Un classico problema che dimostra perché due individui potrebbero non cooperare anche quando sarebbe nel loro interesse farlo.';
    
    // Matrice dei payoff: [punteggio giocatore 1, punteggio giocatore 2]
    this.payoffMatrix = {
      cooperate: {
        cooperate: [3, 3],   // Entrambi cooperano
        defect: [0, 5]       // 1 coopera, 2 tradisce
      },
      defect: {
        cooperate: [5, 0],   // 1 tradisce, 2 coopera
        defect: [1, 1]       // Entrambi tradiscono
      }
    };
  }

  /**
   * Restituisce lo stato iniziale del gioco
   * @returns {object} Stato iniziale
   */
  initialState() {
    return {
      round: 0,
      history: [],
      scores: {
        1: 0,
        2: 0
      }
    };
  }

  /**
   * Risolve un round del gioco
   * @param {string} move1 - Mossa del giocatore 1 ('cooperate' o 'defect')
   * @param {string} move2 - Mossa del giocatore 2 ('cooperate' o 'defect')
   * @param {object} gameState - Stato attuale del gioco
   * @returns {object} Risultato del round
   */
  resolveRound(move1, move2, gameState) {
    // Verifica che le mosse siano valide
    if (!['cooperate', 'defect'].includes(move1) || !['cooperate', 'defect'].includes(move2)) {
      throw new Error('Mossa non valida. Le mosse devono essere "cooperate" o "defect".');
    }
    
    // Ottieni i payoff dalla matrice
    const payoffs = this.payoffMatrix[move1][move2];
    
    return {
      round: gameState.round + 1,
      moves: {
        1: move1,
        2: move2
      },
      payoffs: {
        1: payoffs[0],
        2: payoffs[1]
      }
    };
  }

  /**
   * Aggiorna lo stato del gioco dopo un round
   * @param {object} gameState - Stato attuale del gioco
   * @param {object} roundResult - Risultato del round
   * @returns {object} Nuovo stato del gioco
   */
  updateState(gameState, roundResult) {
    return {
      round: roundResult.round,
      history: [...gameState.history, roundResult],
      scores: {
        1: gameState.scores[1] + roundResult.payoffs[1],
        2: gameState.scores[2] + roundResult.payoffs[2]
      }
    };
  }

  /**
   * Calcola i punteggi finali di una partita
   * @param {object[]} history - Cronologia dei round
   * @returns {object} Punteggi finali
   */
  calculateScores(history) {
    return history.reduce((scores, round) => {
      return {
        1: scores[1] + round.payoffs[1],
        2: scores[2] + round.payoffs[2]
      };
    }, { 1: 0, 2: 0 });
  }

  /**
   * Verifica se una mossa è valida
   * @param {string} move - Mossa da verificare
   * @returns {boolean} True se la mossa è valida
   */
  isValidMove(move) {
    return ['cooperate', 'defect'].includes(move);
  }

  /**
   * Restituisce le mosse possibili
   * @returns {string[]} Array di mosse possibili
   */
  getPossibleMoves() {
    return ['cooperate', 'defect'];
  }

  /**
   * Restituisce una descrizione testuale del risultato di un round
   * @param {object} roundResult - Risultato del round
   * @returns {string} Descrizione testuale
   */
  getResultDescription(roundResult) {
    const { moves, payoffs } = roundResult;
    
    if (moves[1] === 'cooperate' && moves[2] === 'cooperate') {
      return `Entrambi i giocatori hanno cooperato. Ciascuno guadagna ${payoffs[1]} punti.`;
    } else if (moves[1] === 'defect' && moves[2] === 'defect') {
      return `Entrambi i giocatori hanno tradito. Ciascuno guadagna ${payoffs[1]} punti.`;
    } else if (moves[1] === 'cooperate' && moves[2] === 'defect') {
      return `Il giocatore 1 ha cooperato mentre il giocatore 2 ha tradito. Il giocatore 1 guadagna ${payoffs[1]} punti, il giocatore 2 guadagna ${payoffs[2]} punti.`;
    } else {
      return `Il giocatore 1 ha tradito mentre il giocatore 2 ha cooperato. Il giocatore 1 guadagna ${payoffs[1]} punti, il giocatore 2 guadagna ${payoffs[2]} punti.`;
    }
  }
}

export default PrisonersDilemma;
