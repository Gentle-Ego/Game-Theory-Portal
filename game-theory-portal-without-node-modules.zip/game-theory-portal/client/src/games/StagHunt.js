/**
 * Implementazione del gioco Stag Hunt
 * 
 * Questo modulo implementa il gioco Stag Hunt (Caccia al Cervo)
 * utilizzando il motore di teoria dei giochi.
 */

class StagHunt {
  constructor() {
    this.id = 'stag-hunt';
    this.name = 'Stag Hunt';
    this.description = 'Un gioco che modella il conflitto tra sicurezza e cooperazione sociale.';
    
    // Matrice dei payoff: [punteggio giocatore 1, punteggio giocatore 2]
    this.payoffMatrix = {
      stag: {
        stag: [4, 4],   // Entrambi cacciano il cervo (cooperazione)
        hare: [0, 3]    // 1 caccia il cervo, 2 caccia la lepre
      },
      hare: {
        stag: [3, 0],   // 1 caccia la lepre, 2 caccia il cervo
        hare: [2, 2]    // Entrambi cacciano la lepre (sicurezza)
      }
    };
  }

  /**
   * Restituisce lo stato iniziale del gioco
   * @returns {object} Stato iniziale
   */
  initialState() {
    return {
      round: 0,
      history: [],
      scores: {
        1: 0,
        2: 0
      }
    };
  }

  /**
   * Risolve un round del gioco
   * @param {string} move1 - Mossa del giocatore 1 ('stag' o 'hare')
   * @param {string} move2 - Mossa del giocatore 2 ('stag' o 'hare')
   * @param {object} gameState - Stato attuale del gioco
   * @returns {object} Risultato del round
   */
  resolveRound(move1, move2, gameState) {
    // Verifica che le mosse siano valide
    if (!['stag', 'hare'].includes(move1) || !['stag', 'hare'].includes(move2)) {
      throw new Error('Mossa non valida. Le mosse devono essere "stag" o "hare".');
    }
    
    // Ottieni i payoff dalla matrice
    const payoffs = this.payoffMatrix[move1][move2];
    
    return {
      round: gameState.round + 1,
      moves: {
        1: move1,
        2: move2
      },
      payoffs: {
        1: payoffs[0],
        2: payoffs[1]
      }
    };
  }

  /**
   * Aggiorna lo stato del gioco dopo un round
   * @param {object} gameState - Stato attuale del gioco
   * @param {object} roundResult - Risultato del round
   * @returns {object} Nuovo stato del gioco
   */
  updateState(gameState, roundResult) {
    return {
      round: roundResult.round,
      history: [...gameState.history, roundResult],
      scores: {
        1: gameState.scores[1] + roundResult.payoffs[1],
        2: gameState.scores[2] + roundResult.payoffs[2]
      }
    };
  }

  /**
   * Calcola i punteggi finali di una partita
   * @param {object[]} history - Cronologia dei round
   * @returns {object} Punteggi finali
   */
  calculateScores(history) {
    return history.reduce((scores, round) => {
      return {
        1: scores[1] + round.payoffs[1],
        2: scores[2] + round.payoffs[2]
      };
    }, { 1: 0, 2: 0 });
  }

  /**
   * Verifica se una mossa è valida
   * @param {string} move - Mossa da verificare
   * @returns {boolean} True se la mossa è valida
   */
  isValidMove(move) {
    return ['stag', 'hare'].includes(move);
  }

  /**
   * Restituisce le mosse possibili
   * @returns {string[]} Array di mosse possibili
   */
  getPossibleMoves() {
    return ['stag', 'hare'];
  }

  /**
   * Restituisce una descrizione testuale del risultato di un round
   * @param {object} roundResult - Risultato del round
   * @returns {string} Descrizione testuale
   */
  getResultDescription(roundResult) {
    const { moves, payoffs } = roundResult;
    
    if (moves[1] === 'stag' && moves[2] === 'stag') {
      return `Entrambi i giocatori hanno scelto di cacciare il cervo. La cooperazione ha successo e ciascuno guadagna ${payoffs[1]} punti.`;
    } else if (moves[1] === 'hare' && moves[2] === 'hare') {
      return `Entrambi i giocatori hanno scelto di cacciare la lepre. Ciascuno ottiene una piccola ricompensa sicura di ${payoffs[1]} punti.`;
    } else if (moves[1] === 'stag' && moves[2] === 'hare') {
      return `Il giocatore 1 ha scelto di cacciare il cervo mentre il giocatore 2 ha scelto la lepre. Il giocatore 1 non cattura nulla e guadagna ${payoffs[1]} punti, il giocatore 2 cattura una lepre e guadagna ${payoffs[2]} punti.`;
    } else {
      return `Il giocatore 1 ha scelto di cacciare la lepre mentre il giocatore 2 ha scelto il cervo. Il giocatore 1 cattura una lepre e guadagna ${payoffs[1]} punti, il giocatore 2 non cattura nulla e guadagna ${payoffs[2]} punti.`;
    }
  }
}

export default StagHunt;
