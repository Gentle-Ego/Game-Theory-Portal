/**
 * Implementazione del creatore di tornei
 * 
 * Questo modulo fornisce funzionalità per creare e gestire tornei
 * tra diverse strategie nei giochi di teoria dei giochi.
 */

import GameTheoryEngine from './GameTheoryEngine';
import PrisonersDilemma from './PrisonersDilemma';
import HawkDove from './HawkDove';
import StagHunt from './StagHunt';
import PublicGoodsGame from './PublicGoodsGame';
import Strategies from './Strategies';

class TournamentCreator {
  constructor() {
    this.engine = new GameTheoryEngine();
    
    // Registra i giochi
    this.engine.registerGame('prisoners-dilemma', new PrisonersDilemma());
    this.engine.registerGame('hawk-dove', new HawkDove());
    this.engine.registerGame('stag-hunt', new StagHunt());
    this.engine.registerGame('public-goods', new PublicGoodsGame());
    
    // Registra le strategie
    this.registerDefaultStrategies();
  }

  /**
   * Registra le strategie predefinite per tutti i giochi
   */
  registerDefaultStrategies() {
    // Strategie per il Dilemma del Prigioniero
    this.engine.registerStrategy('always-cooperate', Strategies.alwaysCooperate, {
      name: 'Always Cooperate',
      description: 'Coopera sempre, indipendentemente dalla storia del gioco.',
      gameId: 'prisoners-dilemma',
      category: 'Base'
    });
    
    this.engine.registerStrategy('always-defect', Strategies.alwaysDefect, {
      name: 'Always Defect',
      description: 'Tradisce sempre, indipendentemente dalla storia del gioco.',
      gameId: 'prisoners-dilemma',
      category: 'Base'
    });
    
    this.engine.registerStrategy('tit-for-tat', Strategies.titForTat, {
      name: 'Tit for Tat',
      description: 'Coopera al primo turno, poi replica la mossa dell\'avversario nel turno precedente.',
      gameId: 'prisoners-dilemma',
      category: 'Classica'
    });
    
    this.engine.registerStrategy('generous-tit-for-tat', Strategies.generousTitForTat, {
      name: 'Generous Tit for Tat',
      description: 'Come Tit for Tat, ma occasionalmente perdona i tradimenti.',
      gameId: 'prisoners-dilemma',
      category: 'Avanzata'
    });
    
    this.engine.registerStrategy('pavlov', Strategies.pavlov, {
      name: 'Pavlov',
      description: 'Mantiene la stessa mossa se ha vinto, cambia se ha perso.',
      gameId: 'prisoners-dilemma',
      category: 'Avanzata'
    });
    
    this.engine.registerStrategy('gradual', Strategies.gradual, {
      name: 'Gradual',
      description: 'Aumenta gradualmente la punizione per i tradimenti.',
      gameId: 'prisoners-dilemma',
      category: 'Avanzata'
    });
    
    this.engine.registerStrategy('random', Strategies.random, {
      name: 'Random',
      description: 'Sceglie casualmente tra cooperare e tradire.',
      gameId: 'prisoners-dilemma',
      category: 'Base'
    });
    
    // Strategie per Hawk-Dove
    this.engine.registerStrategy('always-hawk', Strategies.alwaysHawk, {
      name: 'Always Hawk',
      description: 'Sceglie sempre Falco (comportamento aggressivo).',
      gameId: 'hawk-dove',
      category: 'Base'
    });
    
    this.engine.registerStrategy('always-dove', Strategies.alwaysDove, {
      name: 'Always Dove',
      description: 'Sceglie sempre Colomba (comportamento pacifico).',
      gameId: 'hawk-dove',
      category: 'Base'
    });
    
    this.engine.registerStrategy('hawk-dove-tit-for-tat', Strategies.hawkDoveTitForTat, {
      name: 'Hawk-Dove Tit for Tat',
      description: 'Replica la mossa dell\'avversario nel turno precedente.',
      gameId: 'hawk-dove',
      category: 'Classica'
    });
    
    // Strategie per Stag Hunt
    this.engine.registerStrategy('always-stag', Strategies.alwaysStag, {
      name: 'Always Stag',
      description: 'Sceglie sempre di cacciare il cervo (cooperazione).',
      gameId: 'stag-hunt',
      category: 'Base'
    });
    
    this.engine.registerStrategy('always-hare', Strategies.alwaysHare, {
      name: 'Always Hare',
      description: 'Sceglie sempre di cacciare la lepre (sicurezza).',
      gameId: 'stag-hunt',
      category: 'Base'
    });
    
    this.engine.registerStrategy('stag-hunt-tit-for-tat', Strategies.stagHuntTitForTat, {
      name: 'Stag Hunt Tit for Tat',
      description: 'Replica la mossa dell\'avversario nel turno precedente.',
      gameId: 'stag-hunt',
      category: 'Classica'
    });
    
    // Strategie per Public Goods Game
    this.engine.registerStrategy('free-rider', Strategies.freeRider, {
      name: 'Free Rider',
      description: 'Non contribuisce mai al bene pubblico.',
      gameId: 'public-goods',
      category: 'Base'
    });
    
    this.engine.registerStrategy('full-contributor', Strategies.fullContributor, {
      name: 'Full Contributor',
      description: 'Contribuisce sempre tutta la sua dotazione al bene pubblico.',
      gameId: 'public-goods',
      category: 'Base'
    });
    
    this.engine.registerStrategy('partial-contributor', Strategies.partialContributor, {
      name: 'Partial Contributor',
      description: 'Contribuisce una percentuale fissa della sua dotazione al bene pubblico.',
      gameId: 'public-goods',
      category: 'Base'
    });
    
    this.engine.registerStrategy('conditional-cooperator', Strategies.conditionalCooperator, {
      name: 'Conditional Cooperator',
      description: 'Contribuisce in base alla media dei contributi degli altri giocatori nel turno precedente.',
      gameId: 'public-goods',
      category: 'Avanzata'
    });
  }

  /**
   * Registra una strategia personalizzata
   * @param {string} id - Identificativo della strategia
   * @param {function} strategyFn - Funzione che implementa la strategia
   * @param {object} metadata - Metadati della strategia
   */
  registerCustomStrategy(id, strategyFn, metadata) {
    this.engine.registerStrategy(id, strategyFn, metadata);
  }

  /**
   * Ottiene tutte le strategie disponibili per un gioco
   * @param {string} gameId - Identificativo del gioco
   * @returns {object} Strategie disponibili
   */
  getAvailableStrategies(gameId) {
    return this.engine.getAllStrategies(gameId);
  }

  /**
   * Crea un torneo round-robin tra le strategie specificate
   * @param {string} gameId - Identificativo del gioco
   * @param {string[]} strategyIds - Array di identificativi delle strategie
   * @param {number} rounds - Numero di round per partita
   * @returns {object} Risultati del torneo
   */
  createRoundRobinTournament(gameId, strategyIds, rounds = 10) {
    return this.engine.runTournament(gameId, strategyIds, rounds, true);
  }

  /**
   * Crea un torneo ad eliminazione tra le strategie specificate (non ancora implementato)
   * @param {string} gameId - Identificativo del gioco
   * @param {string[]} strategyIds - Array di identificativi delle strategie
   * @param {number} rounds - Numero di round per partita
   * @returns {object} Risultati del torneo
   */
  createEliminationTournament(gameId, strategyIds, rounds = 10) {
    // Implementazione futura
    throw new Error('Torneo ad eliminazione non ancora implementato');
  }

  /**
   * Esegue una singola partita tra due strategie
   * @param {string} gameId - Identificativo del gioco
   * @param {string} strategy1Id - Identificativo della prima strategia
   * @param {string} strategy2Id - Identificativo della seconda strategia
   * @param {number} rounds - Numero di round
   * @returns {object} Risultati della partita
   */
  playMatch(gameId, strategy1Id, strategy2Id, rounds = 10) {
    return this.engine.playMatch(gameId, strategy1Id, strategy2Id, rounds);
  }

  /**
   * Analizza i risultati di un torneo e genera statistiche
   * @param {object} tournamentResults - Risultati del torneo
   * @returns {object} Statistiche del torneo
   */
  analyzeTournamentResults(tournamentResults) {
    const { gameId, strategies, results, scores } = tournamentResults;
    
    // Calcola il numero di vittorie, sconfitte e pareggi per ogni strategia
    const stats = {};
    strategies.forEach(id => {
      stats[id] = {
        wins: 0,
        losses: 0,
        draws: 0,
        totalScore: scores[id],
        averageScore: scores[id] / (strategies.length - 1)
      };
    });
    
    // Analizza i risultati delle partite
    results.forEach(match => {
      const strategy1 = match.strategy1;
      const strategy2 = match.strategy2;
      const score1 = match.scores[1];
      const score2 = match.scores[2];
      
      if (score1 > score2) {
        stats[strategy1].wins++;
        stats[strategy2].losses++;
      } else if (score1 < score2) {
        stats[strategy1].losses++;
        stats[strategy2].wins++;
      } else {
        stats[strategy1].draws++;
        stats[strategy2].draws++;
      }
    });
    
    // Calcola il ranking
    const ranking = Object.entries(stats)
      .map(([id, stat]) => ({
        id,
        ...stat,
        totalMatches: stat.wins + stat.losses + stat.draws,
        winRate: stat.wins / (stat.wins + stat.losses + stat.draws)
      }))
      .sort((a, b) => b.totalScore - a.totalScore);
    
    return {
      gameId,
      strategies,
      stats,
      ranking,
      totalMatches: results.length
    };
  }

  /**
   * Genera un report testuale dei risultati del torneo
   * @param {object} tournamentResults - Risultati del torneo
   * @returns {string} Report testuale
   */
  generateTournamentReport(tournamentResults) {
    const analysis = this.analyzeTournamentResults(tournamentResults);
    const { gameId, ranking, totalMatches } = analysis;
    
    let report = `Risultati del Torneo - ${gameId}\n`;
    report += `Totale partite: ${totalMatches}\n\n`;
    
    report += "Classifica:\n";
    ranking.forEach((strategy, index) => {
      report += `${index + 1}. ${strategy.id} - Punteggio: ${strategy.totalScore}, Vittorie: ${strategy.wins}, Sconfitte: ${strategy.losses}, Pareggi: ${strategy.draws}, Win Rate: ${(strategy.winRate * 100).toFixed(2)}%\n`;
    });
    
    return report;
  }
}

export default TournamentCreator;
