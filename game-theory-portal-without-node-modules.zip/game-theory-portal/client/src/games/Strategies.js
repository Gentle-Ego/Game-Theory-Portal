/**
 * Implementazione delle strategie di base per i giochi di teoria dei giochi
 * 
 * Questo modulo fornisce un insieme di strategie predefinite che possono
 * essere utilizzate nei vari giochi implementati.
 */

// Strategie per il Dilemma del Prigioniero

/**
 * Always Cooperate - Coopera sempre
 * @param {object} gameState - Stato attuale del gioco
 * @returns {string} 'cooperate'
 */
export const alwaysCooperate = (gameState) => {
  return 'cooperate';
};

/**
 * Always Defect - Tradisce sempre
 * @param {object} gameState - Stato attuale del gioco
 * @returns {string} 'defect'
 */
export const alwaysDefect = (gameState) => {
  return 'defect';
};

/**
 * Tit for Tat - Coopera al primo turno, poi replica la mossa dell'avversario
 * @param {object} gameState - Stato attuale del gioco
 * @returns {string} 'cooperate' o 'defect'
 */
export const titForTat = (gameState) => {
  const { history, playerId, opponentId } = gameState;
  
  if (history.length === 0) {
    return 'cooperate';
  }
  
  const lastRound = history[history.length - 1];
  const opponentLastMove = lastRound.moves[opponentId];
  
  return opponentLastMove;
};

/**
 * Generous Tit for Tat - Come Tit for Tat, ma occasionalmente perdona
 * @param {object} gameState - Stato attuale del gioco
 * @param {number} forgivenessProbability - Probabilità di perdonare (default: 0.1)
 * @returns {string} 'cooperate' o 'defect'
 */
export const generousTitForTat = (gameState, forgivenessProbability = 0.1) => {
  const { history, playerId, opponentId } = gameState;
  
  if (history.length === 0) {
    return 'cooperate';
  }
  
  const lastRound = history[history.length - 1];
  const opponentLastMove = lastRound.moves[opponentId];
  
  // Se l'avversario ha tradito, c'è una probabilità di perdonare
  if (opponentLastMove === 'defect' && Math.random() < forgivenessProbability) {
    return 'cooperate';
  }
  
  return opponentLastMove;
};

/**
 * Pavlov (Win-Stay, Lose-Shift) - Mantiene la stessa mossa se ha vinto, cambia se ha perso
 * @param {object} gameState - Stato attuale del gioco
 * @returns {string} 'cooperate' o 'defect'
 */
export const pavlov = (gameState) => {
  const { history, playerId, opponentId } = gameState;
  
  if (history.length === 0) {
    return 'cooperate';
  }
  
  const lastRound = history[history.length - 1];
  const myLastMove = lastRound.moves[playerId];
  const opponentLastMove = lastRound.moves[opponentId];
  
  // Se entrambi hanno fatto la stessa mossa (CC o DD), mantieni la tua mossa
  if (myLastMove === opponentLastMove) {
    return myLastMove;
  }
  
  // Altrimenti, cambia mossa
  return myLastMove === 'cooperate' ? 'defect' : 'cooperate';
};

/**
 * Gradual - Aumenta gradualmente la punizione per i tradimenti
 * @param {object} gameState - Stato attuale del gioco
 * @returns {string} 'cooperate' o 'defect'
 */
export const gradual = (gameState) => {
  const { history, playerId, opponentId } = gameState;
  
  if (history.length === 0) {
    return 'cooperate';
  }
  
  // Conta il numero di tradimenti dell'avversario
  let defectionCount = 0;
  for (const round of history) {
    if (round.moves[opponentId] === 'defect') {
      defectionCount++;
    }
  }
  
  // Se l'avversario non ha mai tradito, coopera
  if (defectionCount === 0) {
    return 'cooperate';
  }
  
  // Calcola la lunghezza della punizione in base al numero di tradimenti
  const punishmentLength = defectionCount;
  
  // Controlla se siamo in una fase di punizione
  let consecutiveDefections = 0;
  for (let i = history.length - 1; i >= 0; i--) {
    if (history[i].moves[playerId] === 'defect') {
      consecutiveDefections++;
    } else {
      break;
    }
  }
  
  // Se abbiamo punito abbastanza, torna a cooperare per due round
  if (consecutiveDefections >= punishmentLength) {
    return 'cooperate';
  }
  
  // Altrimenti, continua a punire
  return 'defect';
};

/**
 * Random - Sceglie casualmente tra cooperare e tradire
 * @param {object} gameState - Stato attuale del gioco
 * @param {number} cooperateProbability - Probabilità di cooperare (default: 0.5)
 * @returns {string} 'cooperate' o 'defect'
 */
export const random = (gameState, cooperateProbability = 0.5) => {
  return Math.random() < cooperateProbability ? 'cooperate' : 'defect';
};

// Strategie per Hawk-Dove

/**
 * Always Hawk - Sceglie sempre Falco (comportamento aggressivo)
 * @param {object} gameState - Stato attuale del gioco
 * @returns {string} 'hawk'
 */
export const alwaysHawk = (gameState) => {
  return 'hawk';
};

/**
 * Always Dove - Sceglie sempre Colomba (comportamento pacifico)
 * @param {object} gameState - Stato attuale del gioco
 * @returns {string} 'dove'
 */
export const alwaysDove = (gameState) => {
  return 'dove';
};

/**
 * Hawk-Dove Tit for Tat - Replica la mossa dell'avversario
 * @param {object} gameState - Stato attuale del gioco
 * @returns {string} 'hawk' o 'dove'
 */
export const hawkDoveTitForTat = (gameState) => {
  const { history, playerId, opponentId } = gameState;
  
  if (history.length === 0) {
    return 'dove'; // Inizia pacifico
  }
  
  const lastRound = history[history.length - 1];
  const opponentLastMove = lastRound.moves[opponentId];
  
  return opponentLastMove;
};

// Strategie per Stag Hunt

/**
 * Always Stag - Sceglie sempre di cacciare il cervo (cooperazione)
 * @param {object} gameState - Stato attuale del gioco
 * @returns {string} 'stag'
 */
export const alwaysStag = (gameState) => {
  return 'stag';
};

/**
 * Always Hare - Sceglie sempre di cacciare la lepre (sicurezza)
 * @param {object} gameState - Stato attuale del gioco
 * @returns {string} 'hare'
 */
export const alwaysHare = (gameState) => {
  return 'hare';
};

/**
 * Stag Hunt Tit for Tat - Replica la mossa dell'avversario
 * @param {object} gameState - Stato attuale del gioco
 * @returns {string} 'stag' o 'hare'
 */
export const stagHuntTitForTat = (gameState) => {
  const { history, playerId, opponentId } = gameState;
  
  if (history.length === 0) {
    return 'stag'; // Inizia cooperativo
  }
  
  const lastRound = history[history.length - 1];
  const opponentLastMove = lastRound.moves[opponentId];
  
  return opponentLastMove;
};

// Strategie per Public Goods Game

/**
 * Free Rider - Non contribuisce mai
 * @param {object} gameState - Stato attuale del gioco
 * @returns {number} 0
 */
export const freeRider = (gameState) => {
  return 0;
};

/**
 * Full Contributor - Contribuisce sempre tutto
 * @param {object} gameState - Stato attuale del gioco
 * @returns {number} L'intera dotazione
 */
export const fullContributor = (gameState) => {
  const { endowments, playerId } = gameState;
  return endowments[playerId];
};

/**
 * Partial Contributor - Contribuisce una percentuale fissa della dotazione
 * @param {object} gameState - Stato attuale del gioco
 * @param {number} percentage - Percentuale da contribuire (default: 0.5)
 * @returns {number} Contributo parziale
 */
export const partialContributor = (gameState, percentage = 0.5) => {
  const { endowments, playerId } = gameState;
  return Math.floor(endowments[playerId] * percentage);
};

/**
 * Conditional Cooperator - Contribuisce in base alla media dei contributi precedenti
 * @param {object} gameState - Stato attuale del gioco
 * @returns {number} Contributo basato sulla media
 */
export const conditionalCooperator = (gameState) => {
  const { history, endowments, playerId, numPlayers } = gameState;
  
  if (history.length === 0) {
    return Math.floor(endowments[playerId] * 0.5); // Inizia con il 50%
  }
  
  // Calcola la media dei contributi degli altri giocatori nel round precedente
  const lastRound = history[history.length - 1];
  let totalOtherContributions = 0;
  let otherPlayersCount = 0;
  
  for (const [player, contribution] of Object.entries(lastRound.contributions)) {
    if (parseInt(player) !== playerId) {
      totalOtherContributions += contribution;
      otherPlayersCount++;
    }
  }
  
  const averageContribution = totalOtherContributions / otherPlayersCount;
  
  // Contribuisci leggermente più della media (ma non più della tua dotazione)
  return Math.min(Math.floor(averageContribution * 1.1), endowments[playerId]);
};

// Esporta tutte le strategie
export default {
  // Dilemma del Prigioniero
  alwaysCooperate,
  alwaysDefect,
  titForTat,
  generousTitForTat,
  pavlov,
  gradual,
  random,
  
  // Hawk-Dove
  alwaysHawk,
  alwaysDove,
  hawkDoveTitForTat,
  
  // Stag Hunt
  alwaysStag,
  alwaysHare,
  stagHuntTitForTat,
  
  // Public Goods Game
  freeRider,
  fullContributor,
  partialContributor,
  conditionalCooperator
};
