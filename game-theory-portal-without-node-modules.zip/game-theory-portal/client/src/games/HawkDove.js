/**
 * Implementazione del gioco Hawk-Dove
 * 
 * Questo modulo implementa il gioco Hawk-Dove (Falco-Colomba)
 * utilizzando il motore di teoria dei giochi.
 */

class HawkDove {
  constructor() {
    this.id = 'hawk-dove';
    this.name = 'Hawk-Dove Game';
    this.description = 'Un gioco che modella il conflitto tra comportamenti aggressivi e pacifici.';
    
    // Matrice dei payoff: [punteggio giocatore 1, punteggio giocatore 2]
    this.payoffMatrix = {
      hawk: {
        hawk: [-2, -2],   // Entrambi aggressivi (falco)
        dove: [4, 0]      // 1 aggressivo, 2 pacifico
      },
      dove: {
        hawk: [0, 4],     // 1 pacifico, 2 aggressivo
        dove: [2, 2]      // Entrambi pacifici (colomba)
      }
    };
  }

  /**
   * Restituisce lo stato iniziale del gioco
   * @returns {object} Stato iniziale
   */
  initialState() {
    return {
      round: 0,
      history: [],
      scores: {
        1: 0,
        2: 0
      }
    };
  }

  /**
   * Risolve un round del gioco
   * @param {string} move1 - Mossa del giocatore 1 ('hawk' o 'dove')
   * @param {string} move2 - Mossa del giocatore 2 ('hawk' o 'dove')
   * @param {object} gameState - Stato attuale del gioco
   * @returns {object} Risultato del round
   */
  resolveRound(move1, move2, gameState) {
    // Verifica che le mosse siano valide
    if (!['hawk', 'dove'].includes(move1) || !['hawk', 'dove'].includes(move2)) {
      throw new Error('Mossa non valida. Le mosse devono essere "hawk" o "dove".');
    }
    
    // Ottieni i payoff dalla matrice
    const payoffs = this.payoffMatrix[move1][move2];
    
    return {
      round: gameState.round + 1,
      moves: {
        1: move1,
        2: move2
      },
      payoffs: {
        1: payoffs[0],
        2: payoffs[1]
      }
    };
  }

  /**
   * Aggiorna lo stato del gioco dopo un round
   * @param {object} gameState - Stato attuale del gioco
   * @param {object} roundResult - Risultato del round
   * @returns {object} Nuovo stato del gioco
   */
  updateState(gameState, roundResult) {
    return {
      round: roundResult.round,
      history: [...gameState.history, roundResult],
      scores: {
        1: gameState.scores[1] + roundResult.payoffs[1],
        2: gameState.scores[2] + roundResult.payoffs[2]
      }
    };
  }

  /**
   * Calcola i punteggi finali di una partita
   * @param {object[]} history - Cronologia dei round
   * @returns {object} Punteggi finali
   */
  calculateScores(history) {
    return history.reduce((scores, round) => {
      return {
        1: scores[1] + round.payoffs[1],
        2: scores[2] + round.payoffs[2]
      };
    }, { 1: 0, 2: 0 });
  }

  /**
   * Verifica se una mossa è valida
   * @param {string} move - Mossa da verificare
   * @returns {boolean} True se la mossa è valida
   */
  isValidMove(move) {
    return ['hawk', 'dove'].includes(move);
  }

  /**
   * Restituisce le mosse possibili
   * @returns {string[]} Array di mosse possibili
   */
  getPossibleMoves() {
    return ['hawk', 'dove'];
  }

  /**
   * Restituisce una descrizione testuale del risultato di un round
   * @param {object} roundResult - Risultato del round
   * @returns {string} Descrizione testuale
   */
  getResultDescription(roundResult) {
    const { moves, payoffs } = roundResult;
    
    if (moves[1] === 'hawk' && moves[2] === 'hawk') {
      return `Entrambi i giocatori hanno scelto Falco (comportamento aggressivo). Entrambi perdono energia nel conflitto e guadagnano ${payoffs[1]} punti ciascuno.`;
    } else if (moves[1] === 'dove' && moves[2] === 'dove') {
      return `Entrambi i giocatori hanno scelto Colomba (comportamento pacifico). Condividono la risorsa e guadagnano ${payoffs[1]} punti ciascuno.`;
    } else if (moves[1] === 'hawk' && moves[2] === 'dove') {
      return `Il giocatore 1 ha scelto Falco mentre il giocatore 2 ha scelto Colomba. Il giocatore 1 ottiene tutta la risorsa e guadagna ${payoffs[1]} punti, il giocatore 2 si ritira e guadagna ${payoffs[2]} punti.`;
    } else {
      return `Il giocatore 1 ha scelto Colomba mentre il giocatore 2 ha scelto Falco. Il giocatore 1 si ritira e guadagna ${payoffs[1]} punti, il giocatore 2 ottiene tutta la risorsa e guadagna ${payoffs[2]} punti.`;
    }
  }
}

export default HawkDove;
