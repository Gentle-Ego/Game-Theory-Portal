/**
 * Game Theory Engine - Modulo principale
 * 
 * Questo modulo fornisce le funzionalità di base per implementare
 * diversi giochi di teoria dei giochi.
 */

class GameTheoryEngine {
  constructor() {
    this.games = {};
    this.strategies = {};
  }

  /**
   * Registra un nuovo gioco nel motore
   * @param {string} gameId - Identificativo univoco del gioco
   * @param {object} gameConfig - Configurazione del gioco
   */
  registerGame(gameId, gameConfig) {
    this.games[gameId] = gameConfig;
  }

  /**
   * Registra una nuova strategia nel motore
   * @param {string} strategyId - Identificativo univoco della strategia
   * @param {function} strategyFn - Funzione che implementa la strategia
   * @param {object} metadata - Metadati della strategia (nome, descrizione, autore, ecc.)
   */
  registerStrategy(strategyId, strategyFn, metadata = {}) {
    this.strategies[strategyId] = {
      execute: strategyFn,
      metadata: {
        name: metadata.name || strategyId,
        description: metadata.description || '',
        author: metadata.author || 'Sistema',
        category: metadata.category || 'Generale',
        ...metadata
      }
    };
  }

  /**
   * Ottiene un gioco registrato
   * @param {string} gameId - Identificativo del gioco
   * @returns {object} Configurazione del gioco
   */
  getGame(gameId) {
    return this.games[gameId];
  }

  /**
   * Ottiene una strategia registrata
   * @param {string} strategyId - Identificativo della strategia
   * @returns {object} Strategia con funzione di esecuzione e metadati
   */
  getStrategy(strategyId) {
    return this.strategies[strategyId];
  }

  /**
   * Ottiene tutte le strategie registrate
   * @param {string} gameId - Filtra per gioco specifico (opzionale)
   * @returns {object} Tutte le strategie registrate
   */
  getAllStrategies(gameId = null) {
    if (!gameId) return this.strategies;
    
    return Object.entries(this.strategies)
      .filter(([_, strategy]) => 
        !strategy.metadata.gameId || strategy.metadata.gameId === gameId)
      .reduce((acc, [id, strategy]) => {
        acc[id] = strategy;
        return acc;
      }, {});
  }

  /**
   * Esegue una strategia con un dato stato di gioco
   * @param {string} strategyId - Identificativo della strategia
   * @param {object} gameState - Stato attuale del gioco
   * @returns {*} Risultato dell'esecuzione della strategia
   */
  executeStrategy(strategyId, gameState) {
    const strategy = this.getStrategy(strategyId);
    if (!strategy) throw new Error(`Strategia ${strategyId} non trovata`);
    
    return strategy.execute(gameState);
  }

  /**
   * Esegue un round di gioco tra due strategie
   * @param {string} gameId - Identificativo del gioco
   * @param {string} strategy1Id - Identificativo della prima strategia
   * @param {string} strategy2Id - Identificativo della seconda strategia
   * @param {object} gameState - Stato attuale del gioco
   * @returns {object} Risultato del round
   */
  playRound(gameId, strategy1Id, strategy2Id, gameState) {
    const game = this.getGame(gameId);
    if (!game) throw new Error(`Gioco ${gameId} non trovato`);
    
    const move1 = this.executeStrategy(strategy1Id, {
      ...gameState,
      playerId: 1,
      opponentId: 2
    });
    
    const move2 = this.executeStrategy(strategy2Id, {
      ...gameState,
      playerId: 2,
      opponentId: 1
    });
    
    return game.resolveRound(move1, move2, gameState);
  }

  /**
   * Esegue una partita completa tra due strategie
   * @param {string} gameId - Identificativo del gioco
   * @param {string} strategy1Id - Identificativo della prima strategia
   * @param {string} strategy2Id - Identificativo della seconda strategia
   * @param {number} rounds - Numero di round da giocare
   * @returns {object} Risultato della partita
   */
  playMatch(gameId, strategy1Id, strategy2Id, rounds = 10) {
    const game = this.getGame(gameId);
    if (!game) throw new Error(`Gioco ${gameId} non trovato`);
    
    let gameState = game.initialState();
    const history = [];
    
    for (let i = 0; i < rounds; i++) {
      const roundResult = this.playRound(gameId, strategy1Id, strategy2Id, gameState);
      history.push(roundResult);
      gameState = game.updateState(gameState, roundResult);
    }
    
    return {
      gameId,
      strategy1: strategy1Id,
      strategy2: strategy2Id,
      rounds,
      history,
      finalState: gameState,
      scores: game.calculateScores(history)
    };
  }

  /**
   * Esegue un torneo tra più strategie
   * @param {string} gameId - Identificativo del gioco
   * @param {string[]} strategyIds - Array di identificativi delle strategie
   * @param {number} rounds - Numero di round per partita
   * @param {boolean} roundRobin - Se true, ogni strategia gioca contro tutte le altre
   * @returns {object} Risultati del torneo
   */
  runTournament(gameId, strategyIds, rounds = 10, roundRobin = true) {
    const results = [];
    const scores = {};
    
    // Inizializza i punteggi
    strategyIds.forEach(id => {
      scores[id] = 0;
    });
    
    if (roundRobin) {
      // Ogni strategia gioca contro tutte le altre
      for (let i = 0; i < strategyIds.length; i++) {
        for (let j = i + 1; j < strategyIds.length; j++) {
          const matchResult = this.playMatch(gameId, strategyIds[i], strategyIds[j], rounds);
          results.push(matchResult);
          
          scores[strategyIds[i]] += matchResult.scores[1];
          scores[strategyIds[j]] += matchResult.scores[2];
        }
      }
    } else {
      // Torneo ad eliminazione (da implementare)
      throw new Error('Torneo ad eliminazione non ancora implementato');
    }
    
    return {
      gameId,
      strategies: strategyIds,
      rounds,
      results,
      scores
    };
  }
}

export default GameTheoryEngine;
